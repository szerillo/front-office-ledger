"""
RETENTION v2: expectation-conditioned retention grading, so the channel can
join the FOR composite without punishing clubs for employing stars.

v1 problem: raw leakage (wins produced elsewhere by departed free agents)
scales with how many stars a club employs; the Dodgers bleed ~90 wins simply
because they had the most talent to lose. That is a payroll fact, not a
decision grade, so v1 stayed display-only.

v2 fix: condition on who left. From every "Declared Free Agency" event
league-wide 1998-2023 (3 full future seasons observable), build the empirical
curve E[next-3yr LVM elsewhere | last-3yr LVM here]. A regime is then graded
only on the GAP between what its departures went on to do and what the market
expected departures of that caliber to do, plus a +1.0 win credit per
qualifying-offer departure (the compensation pick; mirrors the QO_CHARGE on
the signing club's FA ledger). Letting a 6-win player walk is not a mistake;
letting the one who still had 12 wins left walk, repeatedly, is.

Merges chan.ret v2 fields into sweep_results.json and (distribution
permitting) adds ret net to the FOR composite.
"""
import json, sqlite3, unicodedata
from collections import defaultdict
from contracts_ext import QO

def norm(nm):
    s = unicodedata.normalize("NFKD", nm or "").encode("ascii", "ignore").decode()
    return s.lower().replace(".", "").replace(" jr", "").strip()

from fa_grade_lib import norm as _qnorm
QOn = set(QO)     # keys are fa_grade_lib.norm names (hyphens folded: "shin soo choo")
QO_CREDIT = 1.0   # v5.9: the compensation pick for a QO walkaway (the QO table is complete for 2012-25)
BY = {int(k): v for k, v in json.load(open("/work/ages.json")).items()}
def age_band(pid, yr):
    """v5.9: age at the departure season: <=29, 30-32, 33-35, 36+"""
    b = BY.get(int(pid)) if pid else None
    if not b: return 1
    a = yr - b
    return 0 if a <= 29 else 1 if a <= 32 else 2 if a <= 35 else 3
def rental(pid, names, yr):
    """v5.9: acquired during the filing season (a deadline rental): his walk
    is part of the trade, whose window already ends at the filing"""
    rec = LVM.get(int(pid)) if pid else None
    if not rec: return False
    here = [tm for (y, tm, v) in rec["rows"] if tm in names and y < yr]
    other = [tm for (y, tm, v) in rec["rows"] if y == yr and tm not in names]
    return not here and bool(other)

_raw = json.load(open("/work/lvm_cache.json"))
LVM = {int(k): v for k, v in _raw.items() if not k.startswith("__")}

cfg = json.load(open("/work/regimes.json"))
ALIAS = {int(k): set(v) for k, v in cfg["aliases"].items()}
TEAMS = {r["teamId"]: ALIAS.get(r["teamId"], {r["team"]}) for r in cfg["regimes"]}

def val(pid, teams, y0, y1, inside=True):
    rec = LVM.get(int(pid)) if pid else None
    if not rec: return 0.0
    return sum(v for yr, tm, v in rec["rows"]
               if y0 <= yr <= y1 and ((tm in teams) == inside))

con = sqlite3.connect("/work/ledger.sqlite"); con.row_factory = sqlite3.Row

def resigned(pid, names, yr):
    """v5.1: a 'Declared Free Agency' filing followed by a season back with the
    same club is a re-signing, not a departure. Counting it as one handed the
    club the whole expected value as 'credit' (the departed player did nothing
    elsewhere because he never left): Jeter, Rivera, Posada and dozens more
    put +133 wins on one card."""
    rec = LVM.get(int(pid)) if pid else None
    if not rec: return False
    return any(y == yr + 1 and tm in names for (y, tm, v) in rec["rows"])

# ---- league expectation curve, all departures 1998-2023 ----
_F1, _F2, _F3 = [], [], []
events = [dict(r) for r in con.execute(
    "select * from sweep_tx where type_desc='Declared Free Agency' and date<='2023-12-31' "
    "order by date, team_id, tx_id, description")]
seen = set(); pairs = []
for r in events:
    pid, tid = r["person_id"], r["team_id"]
    if not pid or tid not in TEAMS: continue
    yr = int(r["date"][:4])
    k = (pid, tid, yr)   # fix pass 1: each club's departure counts once (82 players filed from two clubs in a year)
    if k in seen: continue
    seen.add(k)
    names = TEAMS[tid]
    prior = val(pid, names, yr - 2, yr, inside=True)
    if prior <= 0.5: continue          # same population the regimes are graded on
    if resigned(pid, names, yr): continue
    if rental(pid, names, yr): continue
    fut = val(pid, names, yr + 1, yr + 3, inside=False)
    pairs.append((prior, fut, age_band(pid, yr)))
    _F1.append(val(pid, names, yr + 1, yr + 1, inside=False)); _F2.append(val(pid, names, yr + 1, yr + 2, inside=False)); _F3.append(fut)

EDGES = [0.0, 0.5, 1.0, 2.0, 3.0, 4.5, 6.5, 9.0, 13.0, 99.0]
bins = defaultdict(list)
for p, f, _a in pairs:
    for i in range(len(EDGES) - 1):
        if EDGES[i] <= p < EDGES[i+1]:
            bins[i].append((p, f)); break
CURVE = []   # (bin center by mean prior, mean future, n)
for i in range(len(EDGES) - 1):
    rows = bins.get(i, [])
    if len(rows) < 8: continue
    mp = sum(p for p, _ in rows) / len(rows)
    mf = sum(f for _, f in rows) / len(rows)
    CURVE.append((mp, mf, len(rows)))
print("retention expectation curve (prior 3yr -> expected next-3yr elsewhere):")
for mp, mf, n in CURVE:
    print(f"  prior {mp:5.1f} -> {mf:5.2f}   (n={n})")

def expect(prior):
    c = CURVE
    if prior <= c[0][0]: return c[0][1]
    if prior >= c[-1][0]: return c[-1][1] * (prior / c[-1][0])  # extrapolate ratio
    for (x0, y0, _), (x1, y1, _) in zip(c, c[1:]):
        if x0 <= prior <= x1:
            f = (prior - x0) / (x1 - x0)
            return y0 + f * (y1 - y0)
    return 0.0

# v5.9: age. Letting a 37-year-old walk scored as skill (+0.88 per departure
# at 36+, -0.59 at 29 and under): the curve now carries an age multiplier,
# fit on the same departures (separable: future = curve(prior) x A[age band])
_ab = defaultdict(lambda: [0.0, 0.0])
for p, f, a in pairs: _ab[a][0] += f; _ab[a][1] += expect(p)
AGE_MULT = {a: (x[0] / x[1] if x[1] else 1.0) for a, x in _ab.items()}
print("age multipliers (<=29, 30-32, 33-35, 36+):", {a: round(m, 3) for a, m in sorted(AGE_MULT.items())})
def expect_age(prior, band): return expect(prior) * AGE_MULT.get(band, 1.0)
# centering: the interpolated curve is not exactly mean-preserving; shift it
# so the league-wide mean gap per graded departure is zero by construction
_g = [expect_age(p, a) - f for p, f, a in pairs]
CENTER = -sum(_g) / len(_g) if _g else 0.0
print(f"centering shift per departure: {CENTER:+.3f} (n={len(_g)})")

# Nov 3: departures through the 2025-26 winter are graded. The curve is fit
# on 1998-2023 departures (three full seasons seen); a 2024 departure has two
# seasons to read and a 2025 departure one, so its expectation is scaled by
# the share of the three-year total departures of the past delivered in that
# many seasons. This winter's departures have nothing to read yet.
SHARE = {3: 1.0, 2: round(sum(_F2) / sum(_F3), 3), 1: round(sum(_F1) / sum(_F3), 3)}
print("partial-window shares (1, 2, 3 seasons seen):", SHARE)
LAST_GRADED = 2025
# ---- per-regime grading ----
def grade(nps):
    for thr, g in [(2.6,80),(1.8,75),(1.2,70),(0.8,65),(0.5,60),(0.2,55),
                   (-0.2,50),(-0.6,45),(-1.0,40),(-1.6,35)]:
        if nps >= thr: return g
    return 30
def grade_comp(nps):
    for thr, g in [(8.0,80),(5.5,75),(3.5,70),(2.2,65),(1.2,60),(0.4,55),
                   (-0.4,50),(-1.2,45),(-2.2,40),(-3.5,35)]:
        if nps >= thr: return g
    return 30

res = json.load(open("/work/sweep_results.json"))
REG = {r["teamId"]: r for r in cfg["regimes"]}
nets = []
for r in res:
    tid = r["teamId"]
    start = max(REG[tid]["start"], "1998-01-01")
    names = TEAMS[tid]
    rows = [dict(x) for x in con.execute(
        "select * from sweep_tx where team_id=? and date>=? and type_desc='Declared Free Agency' and date<='2025-12-31' "
        "order by date, tx_id, description",
        (tid, start))]
    seen2 = set(); net2 = 0.0; n2 = 0; qo_n = 0; worst = []
    for x in rows:
        pid = x["person_id"]
        if not pid: continue
        yr = int(x["date"][:4])
        if (pid, yr) in seen2: continue
        seen2.add((pid, yr))
        prior = val(pid, names, yr - 2, yr, inside=True)
        if prior <= 0.5: continue
        if resigned(pid, names, yr): continue
        if rental(pid, names, yr): continue
        _obs = min(3, 2026 - yr)
        if _obs < 1: continue
        fut = val(pid, names, yr + 1, yr + _obs, inside=False)
        exp = (expect_age(prior, age_band(pid, yr)) + CENTER) * SHARE[_obs]
        gap = exp - fut            # positive: departed player did LESS than market expected: good call
        if (_qnorm(x["person_name"]), yr) in QOn:
            gap += QO_CREDIT; qo_n += 1
        net2 += gap; n2 += 1
        if fut - exp > 1.5:
            worst.append((x["person_name"], yr, round(prior,1), round(fut,1), round(exp,1)))
    worst.sort(key=lambda t: -(t[3] - t[4]))
    ret = r["chan"].get("ret") or {}
    ret.update(net2=round(net2, 1), n2=n2, qo=qo_n, g2=grade(net2 / r["seasons"]),
               worst2=[dict(nm=w[0], y=w[1], prior=w[2], fut=w[3], exp=w[4]) for w in worst[:3]])
    r["chan"]["ret"] = ret
    nets.append((r["abbr"], round(net2,1), n2, r["seasons"]))

nets.sort(key=lambda t: -t[1])
print("\nret v2 nets (expectation-conditioned):")
for ab, n, k, s in nets:
    print(f"  {ab:<5} {n:+6.1f} over {k} departures ({s} yrs, {n/s:+.2f}/yr)")

vals = [n for _, n, _, _ in nets]
import statistics
print(f"\nmean {statistics.mean(vals):+.1f} | median {statistics.median(vals):+.1f} | sd {statistics.pstdev(vals):.1f}")

# join composite: v2 is centered by construction; add to FOR total
for r in res:
    net2 = r["chan"]["ret"]["net2"]
    # idempotent: back out whatever an earlier run added (stored at the top
    # level, which archetype.py never resets) before adding this run's value
    r["total"] = round(r["total"] - r.get("ret_applied", 0.0) + net2, 1)
    r["ret_applied"] = net2
    r["forGrade"] = grade_comp(r["total"] / r["seasons"])

json.dump(res, open("/work/sweep_results.json", "w"), indent=1)
print("\nmerged ret v2 into sweep_results.json (composite updated)")
