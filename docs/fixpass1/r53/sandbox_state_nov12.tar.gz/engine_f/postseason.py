"""SWEEP v2 part 1: real postseason detail in the Success grade.

Pulls postseason series 1998-2026 from statsapi, derives per team-season:
berth (played any postseason game), series wins (WC counts when won),
pennant (won LCS), WS title. Blends into the Success grade:

  base = W% points (as v1)  +  2.0/season-normalized bonus mix:
  score/season = 1.2*div + 0.8*berth + 0.6*seriesW + 1.5*pennant + 3.0*WS
  Success 20-80 = W% anchor shifted by postseason rate vs league norm.

Concretely (documented): success_pts = wpct_z + october_z where
  wpct_z = (wpct - .500) * 40      (a .560 club ~ +2.4/season)
  october = (0.8*berths + 0.6*sw + 1.5*pen + 3.0*ws + 1.2*div) / seasons
  october_z = october - 0.55       (league mean: ~1/3 berth rate etc.)
Bands: >=3.2 A+ ... same ladder as channels scaled 2x.

Writes postseason.json {teamId: {year: {berth,sw,pennant,ws}}} and updates
sweep_results.json success blocks in place (po, sw, pen, ws, g).
"""
import json, time, urllib.request

def get(u, tries=3):
    req = urllib.request.Request(u, headers={"User-Agent":"Mozilla/5.0"})
    for a in range(tries):
        try: return json.load(urllib.request.urlopen(req, timeout=40))
        except Exception: time.sleep(2 + 2*a)
    return {}

import os
PS = {}  # (teamId, year) -> dict(berth, sw, pennant, ws)
if os.path.exists("/work/postseason.json"):
    for k, rec in json.load(open("/work/postseason.json")).items():
        tid, y = k.split(":"); PS[(int(tid), int(y))] = rec
def bump(tid, y, k, v=1):
    rec = PS.setdefault((tid, y), dict(berth=0, sw=0, pennant=0, ws=0))
    rec[k] = rec[k] + v if k == "sw" else max(rec[k], v)

have_years = {y for (_, y) in PS}
for yr in range(1998, 2027):
    if yr in have_years and yr < 2026 and not os.environ.get("PS_FULL"): continue
    # refetched seasons are rebuilt from scratch: bump() accumulates series
    # wins and max()-latches pennants, so stale in-progress rows must go
    for key in [k for k in PS if k[1] == yr]: del PS[key]
    d = get(f"https://statsapi.mlb.com/api/v1/schedule/postseason/series?season={yr}&fields=series,id,gameType,games,teams,away,home,team,id,isWinner")
    for s in d.get("series", []):
        gt = s["series"]["gameType"]      # F=WC, D=DS, L=LCS, W=WS
        if gt not in ("F", "D", "L", "W"):
            continue                      # R = regular-season tiebreaker (Game 163): not October
        wins = {}
        teams = set()
        for g in s.get("games", []):
            for side in ("away", "home"):
                t = g["teams"][side]; tid = t["team"]["id"]
                teams.add(tid)
                if t.get("isWinner"): wins[tid] = wins.get(tid, 0) + 1
        if not teams: continue
        need = {"F": 2, "D": 3, "L": 4, "W": 4}.get(gt, 99)
        winner = max(wins, key=wins.get) if wins else None
        if winner is not None and wins[winner] < need and gt in ("D","L","W"):
            winner = None                 # series still in progress
        if gt == "F" and winner is not None and wins[winner] < 2 and len(s.get("games", [])) > 1:
            winner = None
        for tid in teams:
            bump(tid, yr, "berth")
        if winner is not None:
            bump(winner, yr, "sw")
            if gt == "L": bump(winner, yr, "pennant")
            if gt == "W": bump(winner, yr, "ws")
    print(yr, "series:", len(d.get("series", [])), flush=True)
    time.sleep(0.6)

json.dump({f"{tid}:{y}": rec for (tid, y), rec in PS.items()},
          open("/work/postseason.json", "w"))
print("saved postseason.json:", len(PS), "team-seasons")

# ---- blend into sweep_results ----
cfg = json.load(open("/work/regimes.json"))
REG = {r["teamId"]: r for r in cfg["regimes"]}
res = json.load(open("/work/sweep_results.json"))

# W%/division titles over the SAME window as October credit: a regime hired
# after a season ends gets no credit for that season (sweep_score counts the
# hire year itself, which handed e.g. a 2014 NL West title to an October 2014 hire)
WL = {}
for yr in range(1998, 2027):
    d = get(f"https://statsapi.mlb.com/api/v1/standings?leagueId=103,104&season={yr}&standingsTypes=regularSeason")
    for grp in d.get("records", []):
        for t in grp.get("teamRecords", []):
            WL[(t["team"]["id"], yr)] = (t.get("wins", 0), t.get("losses", 0),
                                          1 if str(t.get("divisionRank")) == "1" else 0)
    time.sleep(0.3)
print("standings:", len(WL), "team-seasons")

def sgrade(pts):
    for thr, g in [(4.5,80),(3.4,75),(2.6,70),(1.9,65),(1.3,60),(0.7,55),
                   (0.0,50),(-0.8,45),(-1.6,40),(-2.6,35)]:
        if pts >= thr: return g
    return 30

print(f"\n{'team':<6}{'W%':>6}{'div':>4}{'PO':>4}{'SW':>4}{'pen':>4}{'WS':>4}   success")
for r in res:
    tid = r["teamId"]
    # v5.4: October credit and the record follow regime_window: W-L from the
    # hire date, titles and October only for seasons the regime finished
    from regime_window import record as _rec, seasons as _seas
    _wl = {k: [v[0], v[1], v[2]] for k, v in WL.items()}
    _w, _l, _div, yrs = _rec(tid, REG[tid]["start"], None, _wl)
    po = sw = pen = ws = 0
    for y in yrs:
        rec = PS.get((tid, y))
        if rec:
            po += rec["berth"]; sw += rec["sw"]; pen += rec["pennant"]; ws += rec["ws"]
    s = r["success"]
    w, l = _w, _l
    if w + l:
        s.update(w=w, l=l, wpct=f"{w/(w+l):.3f}".lstrip("0"), div=_div)
    else:
        s.update(w=0, l=0, wpct=".500", div=0)
    wpct = float(s["wpct"])
    seasons = max(_seas(REG[tid]["start"]), 0.5)
    october = (1.2 * (s["div"] if isinstance(s["div"], int) else 0)
               + 0.8 * po + 0.6 * sw + 1.5 * pen + 3.0 * ws) / seasons
    pts = (wpct - 0.500) * 40 + (october - 0.55)
    s.update(po=po, sw=sw, pen=pen, ws=ws, g=sgrade(pts))
    r["titles"] = ws
    print(f"{r['abbr']:<6}{s['wpct']:>6}{s['div']:>4}{po:>4}{sw:>4}{pen:>4}{ws:>4}   {sgrade(pts)} ({pts:+.2f})")

json.dump(res, open("/work/sweep_results.json", "w"), indent=1)
print("\nupdated success blocks in sweep_results.json")
