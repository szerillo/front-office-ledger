"""
THE 30-REGIME SWEEP: score every active MLB front office with Ledger WAR v0.
Outputs sweep_results.json for the prototype leaderboard.

Sweep v1 rules (documented; versioned):
  TRADE   acquired = LVM seasons with this club, [tx_year, tx_year+5];
          surrendered = LVM seasons elsewhere, same window. Net from this seat.
  WAIVER/RULE 5  claim: LVM with club [y, y+3]; loss: -LVM elsewhere [y, y+3].
  DRAFT   picks rounds 1-5 (value tail beyond r5 noted, not graded):
          realized = LVM while on drafting org; expectation = slot curve x
          maturity schedule. FA: raw LVM captured [y, y+3], UNGRADED pending a
          contracts feed. Success: W% + division titles from standings feed.
SWEEP v2: trades use CONTROL WINDOWS (value counts while the player stays
with the club, 6-season cap, stopping when he leaves the org: a re-signing
is a new decision), win-curve LEVERAGE (each delivered season weighted by
L(w) = 0.5 + 1.3*exp(-(w-89)^2/200) at the receiving club's win total, so
wins delivered to a contender count up to ~1.8x and wins to a 70-win club
~0.65x) and 10%/yr TIME DISCOUNTING back to the deal date, per methodology
v0.2. FA/waiver channels stay unweighted (cost and value accrue in the same
seasons, so leverage cancels to first order there).
LEGACY CRUDENESS (v1): windows were calendar approximations (5-yr cap
mitigates); no leverage/discounting (v0.2 applies at the decision page
level, not yet in the sweep); LVM gaps as documented in ledger_war.py.
"""
from era_names import draft_day
from asset_rules import control_value, draft_maturity, draft_band
MOVE_POP = {"waiver": [], "draft": []}
from asset_rules import contract_cost, trade_window, waiver_window, waiver_pairs, held_window, DRAFT_K, DRAFT_SHAPE, draft_k
import json, math, sqlite3, sys
from collections import defaultdict
from tradegroup import dedupe_rows, group_trades
from ledger_war import get, API, lvm_batting, lvm_pitching

DB = "/work/ledger.sqlite"
END_YEAR = 2026

# ---------- draft curve (from elias_ledger) ----------
def slot_expectation(pick):
    table = [(1, 9.9), (2, 7.5), (3, 6.7), (5, 5.5), (8, 4.6), (12, 3.6), (17, 3.0),
             (22, 2.6), (30, 2.1), (45, 1.5), (65, 1.1), (90, 0.85), (120, 0.6),
             (200, 0.35), (400, 0.18), (620, 0.10)]
    if pick <= 1: return table[0][1]
    for (p1, v1), (p2, v2) in zip(table, table[1:]):
        if pick <= p2:
            f = (math.log(pick) - math.log(p1)) / (math.log(p2) - math.log(p1))
            return v1 + f * (v2 - v1)
    return 0.10
MATURITY = {0: 0.0, 1: 0.02, 2: 0.10, 3: 0.22, 4: 0.38, 5: 0.55, 6: 0.70, 7: 0.82}
def maturity(dy, asof=2026):
    n = max(0, asof - dy)
    return MATURITY.get(n, 0.82 + min(0.18, 0.02 * (n - 7)))

def grade(nps):
    for thr, g in [(2.6,80),(1.8,75),(1.2,70),(0.8,65),(0.5,60),(0.2,55),
                   (-0.2,50),(-0.6,45),(-1.0,40),(-1.6,35)]:
        if nps >= thr: return g
    return 30
def grade_comp(nps):
    for thr, g in [(8.0,80),(5.5,75),(3.5,70),(2.2,65),(1.2,60),(0.4,55),
                   (-0.4,50),(-1.2,45),(-2.2,40),(-3.5,35)]:
        if nps >= thr: return g
    return 30
def success_grade(wpct, div, seasons=6):
    base = 65 if wpct>=.560 else 60 if wpct>=.540 else 55 if wpct>=.520 else \
           50 if wpct>=.500 else 45 if wpct>=.480 else 40 if wpct>=.460 else 35 if wpct>=.440 else 30
    # v5.9: the division-title bonus is a RATE (titles per season in the seat),
    # so a 21-season tenure with 4 titles no longer earns the full bonus that a
    # 4-season tenure with 4 titles does; one title every two seasons = +10
    return min(80, base + min(10, round(20 * div / max(seasons, 1))))

# ---------- per-team per-year LVM ----------
def player_team_seasons(ids):
    out = {}
    ids = [i for i in ids if i]
    for i in range(0, len(ids), 40):
        chunk = ",".join(str(x) for x in ids[i:i+40])
        try:
            d = get(f"{API}/people?personIds={chunk}&hydrate=stats(group=[hitting,pitching],type=[yearByYear])")
        except Exception as e:
            print(f"  batch fail {i}: {e}", flush=True); continue
        for p in d.get("people", []):
            pos = p["primaryPosition"]["abbreviation"]
            rows = []
            for grp in p.get("stats", []):
                g = grp["group"]["displayName"]
                for sp in grp.get("splits", []):
                    tm = (sp.get("team") or {}).get("name")
                    if not tm: continue
                    yr = int(sp["season"]); st = sp["stat"]
                    if g == "hitting" and st.get("plateAppearances"):
                        rows.append((yr, tm, lvm_batting(st, yr, pos)))
                    elif g == "pitching" and st.get("inningsPitched"):
                        rows.append((yr, tm, lvm_pitching(st, yr)))
            out[p["id"]] = dict(name=p["fullName"], rows=rows)
        if (i // 40) % 10 == 0: print(f"  LVM {i}/{len(ids)}", flush=True)
    return out

def val(pid, teams, y0, y1, inside=True):
    rec = LVM.get(int(pid)) if pid else None
    if not rec: return 0.0
    tot = 0.0
    for yr, tm, v in rec["rows"]:
        if y0 <= yr <= y1 and ((tm in teams) == inside):
            tot += v
    return tot

def val_series(pid, teams, y0, y1, inside=True):
    """per-season version of val() (value-time ledger for validation)"""
    rec = LVM.get(int(pid)) if pid else None
    out = defaultdict(float)
    if not rec: return out
    for yr, tm, v in rec["rows"]:
        if y0 <= yr <= y1 and ((tm in teams) == inside):
            out[yr] += v
    return out

# ---------- main ----------
cfg = json.load(open("/work/regimes.json"))

def club_names(team):
    """v5.1: every name a club has gone by (Indians/Guardians, Oakland
    Athletics/Athletics, Marlins, Expos/Nationals...). Valuing a departed
    piece on the single name in the transaction row closed his window at the
    club's rename, so the two seats of one trade stopped mirroring."""
    for _r in cfg["regimes"]:
        _al = set(cfg["aliases"].get(str(_r["teamId"]), [])) | {_r["team"]}
        if team in _al: return _al
    return {team}
ALIAS = {int(k): set(v) for k, v in cfg["aliases"].items()}
con = sqlite3.connect(DB); con.row_factory = sqlite3.Row

# collect universe
universe = set()
def mirror_losses(rows, names, start, end="9999-12-31"):
    """v5.8: before 2009 the feed files a waiver claim or Rule 5 pick only on
    the claiming club. Add the losing club's side from the claim's from_team
    so the channel is two-sided in every era."""
    have = {(r["date"], r["person_id"], r["type_desc"]) for r in rows}
    q = ("select * from sweep_tx where type_desc in ('Claimed Off Waivers','Rule 5 Selection') "
         "and date>=? and date<=? and from_team in (%s)" % ",".join("?" * len(names))
         + " order by date, (description like '%(Retrosheet archive)'), tx_id, description, person_id, from_team, to_team")   # fix pass 1 rule 8
    add = []
    for r in con.execute(q, (start, end, *names)):
        r = dict(r)
        k = (r["date"], r["person_id"], r["type_desc"])
        if k in have or (r["to_team"] in names): continue
        have.add(k); add.append(r)
    return rows + add

regime_rows = {}
for reg in cfg["regimes"]:
    tid = reg["teamId"]; start = max(reg["start"], "1998-01-01")
    rows = [dict(r) for r in con.execute(
        "select * from sweep_tx where team_id=? and date>=? and type_desc in "
        "('Trade','Claimed Off Waivers','Rule 5 Selection','Signed as Free Agent','Declared Free Agency')"
        " order by date, (description like '%(Retrosheet archive)'), tx_id, description, person_id, from_team, to_team",   # fix pass 1 rule 8
        (tid, start))]
    regime_rows[tid] = mirror_losses(dedupe_rows(rows, tid, start), ALIAS.get(tid, {reg['team']}), start)
    for r in rows:
        if r["person_id"]: universe.add(int(r["person_id"]))
drafts = {}
for reg in cfg["regimes"]:
    tid = reg["teamId"]
    names = ALIAS.get(tid, {reg["team"]})
    y0 = max(int(reg["start"][:4]) + (0 if reg["start"][:10] <= draft_day(int(reg["start"][:4])) else 1), 1998)   # v5.8: the real draft date
    q = "select * from draft_picks where cast(year as int)>=? and team in (%s) order by cast(year as int), cast(pick_overall as int), person_id, team" % \
        ",".join("?"*len(names))
    picks = [dict(r) for r in con.execute(q, (y0, *names))]
    _sp = set(); picks = [p for p in picks if not ((p['person_id'], p['year'], p['pick_overall']) in _sp or _sp.add((p['person_id'], p['year'], p['pick_overall'])))]   # v5.8: one row per pick
    drafts[tid] = picks
    for p in picks:
        if p["person_id"]: universe.add(int(p["person_id"]))
print(f"universe: {len(universe)} persons", flush=True)
REDRAFT = {}
for pid, yy in con.execute("select person_id, cast(year as int) from draft_picks where person_id is not null order by cast(year as int), cast(pick_overall as int), person_id, team"):
    REDRAFT.setdefault(str(pid), set()).add(yy)
REDRAFT = {k: v for k, v in REDRAFT.items() if len(v) > 1}
import os
from lvm15 import player_team_seasons_v15
if os.path.exists("/work/lvm_cache.json"):
    _raw = json.load(open("/work/lvm_cache.json"))
    _meta = {k: v for k, v in _raw.items() if k.startswith("__")}
    LVM = {int(k): v for k, v in _raw.items() if not k.startswith("__")}
    missing = sorted(universe - set(LVM))
    if missing: LVM.update(player_team_seasons_v15(missing))
else:
    _meta = {"__lvm_v15__": True}
    LVM = player_team_seasons_v15(sorted(universe))
_dump = {str(k): v for k, v in LVM.items()}
_dump.update(_meta)
json.dump(_dump, open("/work/lvm_cache.json", "w"))
print(f"LVM ready for {len(LVM)} persons", flush=True)

# standings for success
wl = defaultdict(lambda: [0, 0, 0])  # (team, year) -> [w, l, divrank1]
for yr in range(1998, 2027):
    try:
        d = get(f"{API}/standings?leagueId=103,104&season={yr}&standingsTypes=regularSeason")
    except Exception: continue
    for recgrp in d.get("records", []):
        for t in recgrp.get("teamRecords", []):
            wl[(t["team"]["id"], yr)] = [t.get("wins",0), t.get("losses",0), 1 if str(t.get("divisionRank"))=="1" else 0]
print("standings loaded", flush=True)

POS = json.load(open("/work/positions.json"))
PITPOS = {"RHP", "LHP", "SP", "RP"}
def ptype(pid):
    return "pit" if POS.get(str(pid)) in PITPOS else "bat"

# at-the-time prospect marks (Pipeline archive, for process-vs-outcome verdicts)
import math as _math
_V_ANCHOR = [(1,8.0),(3,7.0),(5,6.5),(10,5.5),(15,4.8),(25,4.0),(40,3.2),
             (50,2.8),(75,2.0),(100,1.5)]   # legacy combined
# v5.4: hitters and pitchers apart (same anchors as asset_rules / desk_data vrankH, vrankP)
_V_ANCHOR_H = [(1,12.4),(3,10.0),(5,8.8),(10,7.3),(15,6.4),(25,5.3),(40,4.2),
               (50,3.7),(75,2.8),(100,2.2)]
_V_ANCHOR_P = [(1,6.7),(3,5.5),(5,4.9),(10,4.2),(15,3.7),(25,3.2),(40,2.6),
               (50,2.4),(75,2.0),(100,1.6)]
def _vrank(rank, pit=None):
    a = _V_ANCHOR if pit is None else _V_ANCHOR_P if pit else _V_ANCHOR_H
    if rank <= a[0][0]: return a[0][1]
    if rank >= a[-1][0]: return a[-1][1]
    for (x0,y0),(x1,y1) in zip(a, a[1:]):
        if x0 <= rank <= x1:
            f = (_math.log(rank)-_math.log(x0))/(_math.log(x1)-_math.log(x0))
            return y0 + f*(y1-y0)
try:
    _ranks_raw = json.load(open("/work/prospect_ranks.json"))
    PRANK = {}
    PRANK_PIT = {}   # v5.4: the list's own position (P = pitcher) picks the curve
    for _rr in _ranks_raw:
        PRANK.setdefault(str(_rr["pid"]), {})[_rr["year"]] = _rr["rank"]
        PRANK_PIT[str(_rr["pid"])] = (_rr.get("pos") == "P")
except Exception:
    PRANK = {}; PRANK_PIT = {}
def att_mark(pid, deal_date):
    """prospect mark at the time of the deal: the nearest preseason list at
    or before the deal (offseason deals read the next list)."""
    rk = PRANK.get(str(pid))
    if not rk: return None
    y, m = int(deal_date[:4]), int(deal_date[5:7])
    list_y = y + 1 if m >= 10 else y
    for cand in (list_y, list_y - 1):
        if cand in rk: return _vrank(rk[cand], PRANK_PIT.get(str(pid), ptype(pid) == "pit"))
    return None

NAME2TID = {}
for _reg in cfg["regimes"]:
    NAME2TID[_reg["team"]] = _reg["teamId"]
    for _al in ALIAS.get(_reg["teamId"], set()):
        NAME2TID[_al] = _reg["teamId"]

import math
def lev(team_name_or_names, yr):
    """win-curve leverage at the receiving club's final win total (proxy
    for decision-time projection); 1.0 when unknown (minors, pre-2005)."""
    if isinstance(team_name_or_names, set):
        tids = {NAME2TID.get(n) for n in team_name_or_names} - {None}
        tid = next(iter(tids), None)
    else:
        tid = NAME2TID.get(team_name_or_names)
    rec = wl.get((tid, yr)) if tid else None
    if not rec or (rec[0] + rec[1]) < 100: return 1.0
    w = rec[0] * 162 / (rec[0] + rec[1])
    return 0.5 + 1.3 * math.exp(-((w - 89) ** 2) / 200.0)

def val_control(pid, teams, y0, cap=6, weight=True, date=None, series=False, sender=None):
    """v5.8: asset accounting (asset_rules.trade_window): the control window
    from the trade wherever the player plays it, net of the salary that moves
    with him, ending at a new contract, a free-agent filing or a release."""
    t, s = trade_window(pid, teams, date or f"{y0}-07-01", lev=lev, cap=cap, weight=weight, sender=sender)
    return (t, s) if series else t


results = []
for reg in cfg["regimes"]:
    tid = reg["teamId"]; names = ALIAS.get(tid, {reg["team"]})
    start = max(reg["start"], "1998-01-01"); y_start = int(start[:4])
    # v5.4: seat time in real seasons (a June hire holds about half of that
    # season; a hire after the last completed season holds none yet)
    from regime_window import seasons as _seas, record as _rec
    seat = _seas(start)
    seasons = max(seat, 0.1)
    decs = []
    ynet = defaultdict(float)
    # trades
    trades = {"rows": []}
    seen_fa = set(); seen_walk = set(); fa_raw = 0.0; n_fa = 0; walk = []
    dna = dict(draft=dict(pit=0.0, bat=0.0), trade_in=dict(pit=0.0, bat=0.0),
               trade_out=dict(pit=0.0, bat=0.0), waiver=dict(pit=0.0, bat=0.0))
    n_wv = n_r5 = 0; wv_net = 0.0
    ALLX = dict(draft=[], waiver=[], walk=[])   # v5.7: every decision of each kind, for the card's full lists
    _WP, _WUSED = waiver_pairs(regime_rows[tid], names)   # Nov 3: claimed, then lost again = one decision
    for r in regime_rows[tid]:
        t = r["type_desc"]; yr = int(r["date"][:4])
        if t == "Trade":
            trades["rows"].append(r)
        elif t == "Claimed Off Waivers":
            claim = r["to_team"] in names
            if not claim and (r["person_id"], r["date"]) in _WUSED: continue   # graded inside the claim it undid
            _d1 = _WP.get((r["person_id"], r["date"])) if claim else None
            _vs = held_window(r["person_id"], names, r["date"], _d1)[1] if _d1 else waiver_window(r["person_id"], names if claim else club_names(r["to_team"]), r["date"])[1]
            v = sum(_vs.values())
            net = v if claim else -v
            wv_net += net; n_wv += 1
            for _y, _x in _vs.items(): ynet[_y] += (_x if claim else -_x)
            MOVE_POP["waiver"].append([0.5, round(net, 2)])
            ALLX["waiver"].append([r["date"], r["person_name"] or "?", (f"claimed, lost again {_d1}" if _d1 else "claimed") if claim else "lost on waivers", round(net, 1), r["person_id"]])
            dna["waiver"][ptype(r["person_id"])] += net
            if abs(net) > 0.05:
                decs.append(dict(d=r["date"], ch="waiver", net=round(net,1), st=0.5,
                                 h=((r["description"] or "waiver claim")[:80] + (f" Lost him again on {_d1}." if _d1 else ""))[:140],
                                 sides=[[(f"Claimed, then lost again ({_d1}) · what he produced here, net of salary" if _d1 else "Claimed · next 4 seasons, net of salary" if claim else "Lost on waivers · his next 4 seasons, net of salary"),
                                         [[r["person_name"] or "?", f"{net:+.1f}"]]],
                                        ["Baseline", [["waiver channel expectation", "0.0"]]]],
                                 pids=[r["person_id"]]))
        elif t == "Rule 5 Selection":
            pick = r["to_team"] in names
            if not pick and (r["person_id"], r["date"]) in _WUSED: continue
            _d1 = _WP.get((r["person_id"], r["date"])) if pick else None
            _vs = held_window(r["person_id"], names, r["date"], _d1)[1] if _d1 else waiver_window(r["person_id"], names if pick else club_names(r["to_team"]), r["date"])[1]
            v = sum(_vs.values())
            r5n = (v if pick else -v)
            wv_net += r5n; n_r5 += 1
            for _y, _x in _vs.items(): ynet[_y] += (_x if pick else -_x)
            ALLX["waiver"].append([r["date"], r["person_name"] or "?", "Rule 5 pick" if pick else "lost in Rule 5", round(r5n, 1), r["person_id"]])
        elif t == "Declared Free Agency":
            pid = r["person_id"]
            if pid and (pid, r["date"]) not in seen_walk:      # v5.9: the feed and the archive can both file one filing
                seen_walk.add((pid, r["date"]))
                played_here = val(pid, names, yr - 2, yr, inside=True)
                back = any(y == yr + 1 and tm in names for (y, tm, v) in (LVM.get(int(pid)) or {}).get("rows", []))   # re-signed, not a walk (ret2.resigned)
                if played_here > 0.5 and not back:
                    lost = val(pid, names, yr + 1, yr + 3, inside=False)
                    ALLX["walk"].append([r["date"], r["person_name"] or "?", round(-lost, 1), round(played_here, 1), pid])
                    if lost > 1.0:
                        walk.append(dict(d=r["date"], ch="walk", net=round(-lost, 1),
                            h=f"Let {r['person_name']} walk as a free agent · {lost:.1f} LVM elsewhere over the next 3 seasons",
                            sides=[["Production lost (next 3 seasons, other clubs)", [[r["person_name"], f"{-lost:+.1f}"]]],
                                   ["Received", [["nothing (no compensation modeled yet)", "0.0"]]]],
                            pids=[r["person_id"]]))
        elif t == "Signed as Free Agent":
            key = (r["date"], r["person_id"])
            if key in seen_fa or "minor league" in (r["description"] or "").lower(): continue
            seen_fa.add(key); n_fa += 1
            fa_raw += val(r["person_id"], names, yr, yr+3, inside=True)
    tr_net = 0.0
    pname = {}
    for x in regime_rows[tid]:
        if x["person_id"]: pname[x["person_id"]] = x["person_name"]
    trade_groups = group_trades(trades["rows"], names)
    for (d, desc, rs) in trade_groups:
        yr = int(d[:4])
        pids_in  = {x["person_id"] for x in rs if x["to_team"] in names and x["person_id"]}
        outs = {x["person_id"]: x["to_team"] for x in rs
                if x["from_team"] in names and x["person_id"] and x["to_team"]}
        ins_det, out_det = [], []
        ins_from = {x["person_id"]: x["from_team"] for x in rs if x["to_team"] in names and x["person_id"]}
        for p in pids_in:
            _t, _s = val_control(p, names, yr, date=d, series=True, sender=club_names(ins_from.get(p, "")))
            ins_det.append((p, pname.get(p, "?"), _t))
            for _y, _x in _s.items(): ynet[_y] += _x
        for p, dest in outs.items():
            _t, _s = val_control(p, club_names(dest), yr, date=d, series=True, sender=names)
            out_det.append((p, pname.get(p, "?"), dest, _t))
            for _y, _x in _s.items(): ynet[_y] -= _x
        vin  = sum(v for (_, _, v) in ins_det)
        vout = sum(v for (_, _, _, v) in out_det)
        for (p, _, v) in ins_det: dna["trade_in"][ptype(p)] += v
        for (p, _, _, v) in out_det: dna["trade_out"][ptype(p)] += v
        net = vin - vout; tr_net += net
        if abs(net) >= 0.8:
            att_out = [(nm, att_mark(p, d)) for (p, nm, _, _) in out_det]
            att_in  = [(nm, att_mark(p, d)) for (p, nm, _) in ins_det]
            att = dict(out=round(sum(v for (_, v) in att_out if v), 1),
                       n_out=sum(1 for (_, v) in att_out if v),
                       inn=round(sum(v for (_, v) in att_in if v), 1),
                       n_in=sum(1 for (_, v) in att_in if v))
            dests = sorted({dest for (_, _, dest, _) in out_det})
            sides = [["Acquired (control-window value, net of salary)",
                      [[nm, f"{v:+.1f}"] for (_, nm, v) in sorted(ins_det, key=lambda t: -t[2])] or [["(no valued players)", "0.0"]]],
                     ["Surrendered · value realized on " + (", ".join(dests) if dests else "counterparty"),
                      [[nm, f"{-v:+.1f}"] for (_, nm, _, v) in sorted(out_det, key=lambda t: -t[3])] or [["(no valued players)", "0.0"]]]]
            decs.append(dict(d=d, ch="trade", net=round(net,1), st=round(max(abs(vin), abs(vout)), 2), h=(desc or "trade"),
                             vin=round(vin,1), vout=round(vout,1), sides=sides, att=att,
                             pids=[p for (p, _, _) in ins_det] + [p for (p, _, _, _) in out_det]))
    # draft
    dr_real = dr_exp = 0.0; n_mat = 0
    for p in drafts[tid]:
        yr = int(p["year"]); pk = int(p["pick_overall"])
        # unsigned-pick screen: the same player drafted again in a later year
        # means this pick never signed; realized value is zero (any later MLB
        # time with this club came via a different decision) and the slot
        # charge is halved (the comp pick for an unsigned early pick).
        later = REDRAFT.get(str(p["person_id"]), ())
        unsigned = any(y2 > yr for y2 in later)
        # v5.5 asset accounting (asset_rules.py): the pick is worth what the
        # player produced in his six control seasons, wherever he played them;
        # a later trade is graded in the trade channel, never here as well
        _prec = LVM.get(int(p["person_id"])) if p["person_id"] else None
        _dd = draft_day(yr)
        _rs = {} if unsigned else control_value(_prec, pid=p["person_id"], after=_dd, series=True)
        realized = sum(_rs.values())
        realized_here = 0.0 if unsigned else control_value(_prec, names, pid=p["person_id"], after=_dd)
        exp = slot_expectation(pk) * draft_band(p.get("round")) * draft_maturity(yr) * (0.5 if unsigned else 1.0)   # Nov 3: rounds 6+ carry their band factor
        dr_real += realized; dr_exp += exp; n_mat += (exp >= 0.05)
        net = realized - exp
        # value-time: realized value lands in the season it was produced; the
        # slot expectation is charged as the maturity curve says it accrues
        for _y, _x in _rs.items(): ynet[_y] += _x
        _slot = exp / max(draft_maturity(yr), 1e-9)
        for _y in range(yr, END_YEAR + 1):
            _inc = draft_k(yr) * (DRAFT_SHAPE.get(_y - yr, 1.0) - (DRAFT_SHAPE.get(_y - yr - 1, 1.0) if _y > yr else 0.0))
            ynet[_y] -= _slot * _inc
        MOVE_POP["draft"].append([round(exp, 2), round(net, 2)])
        _late = draft_band(p.get("round")) != 1.0 or str(p.get("round", "1")).isdigit() and int(p.get("round")) > 5
        if not _late or realized >= 0.5: ALLX["draft"].append([draft_day(yr), p["person_name"], pk, round(realized, 1), round(realized_here, 1), round(exp, 1), round(net, 1), p["person_id"]])
        dna["draft"][ptype(p["person_id"])] += net
        if abs(net) >= 1.2:
            decs.append(dict(d=draft_day(yr), ch="draft", net=round(net,1), st=round(exp, 2),
                             h=f"Drafted {p['person_name']} (#{pk} overall, {yr})",
                             sides=[["Produced in his control seasons", [[p["person_name"] + " · with this club", f"{realized_here:+.1f}"]]
                                     + ([[ "· for other clubs after a trade or move (graded in that decision)", f"{realized - realized_here:+.1f}"]] if abs(realized - realized_here) >= 0.05 else [])],
                                    ["Slot expectation", [[f"pick #{pk}, maturity-adjusted", f"{-exp:+.1f}"]]]],
                             pids=[p["person_id"]]))
    dr_net = dr_real - dr_exp
    total = tr_net + dr_net + wv_net
    w, l, div, _octs = _rec(tid, start, None, wl)
    wpct = w / (w + l) if (w + l) else 0.5
    decs.sort(key=lambda x: (-abs(x["net"]), x.get("d") or "", x.get("h") or "", str(x.get("pids"))))   # fix pass 1 rule 5
    walk.sort(key=lambda x: (x["net"], x.get("d") or "", x.get("h") or "", str(x.get("pids"))))
    def chbw(ch, n=5):
        pool = [d for d in decs if d["ch"] == ch]
        best = sorted([d for d in pool if d["net"] > 0], key=lambda x: (-x["net"], x.get("d") or "", x.get("h") or "", str(x.get("pids"))))[:n]
        worst = sorted([d for d in pool if d["net"] < 0], key=lambda x: (x["net"], x.get("d") or "", x.get("h") or "", str(x.get("pids"))))[:n]
        return dict(best=best, worst=worst)
    results.append(dict(
        id=reg["abbr"].lower(), teamId=tid, exec=reg["exec"], team=reg["team"], abbr=reg["abbr"],
        start=y_start, seasons=round(seasons, 1), seatSeasons=seat, startDate=reg["start"], flags=reg.get("flags", []),
        chan=dict(
            trade=dict(net=round(tr_net,1), g=grade(tr_net/seasons), n=sum(1 for (_, _, rs) in trade_groups if any(x["person_id"] and str(x["person_id"]) != "0" and (x["to_team"] in names or (x["from_team"] in names and x["to_team"])) for x in rs))),
            draft=dict(net=round(dr_net,1), g=(grade(dr_net/seasons) if n_mat >= 3 else None), n=len(drafts[tid])),
            waiver=dict(net=round(wv_net,1), g=grade(wv_net/seasons), n=n_wv+n_r5),
            fa=dict(net=round(fa_raw,1), g=None, n=n_fa),
        ),
        total=round(total,1), forGrade=grade_comp(total/seasons),
        success=dict(wpct=f"{wpct:.3f}".lstrip('0'), div=div, g=success_grade(wpct, div, seasons), w=w, l=l),
        cum=[round(sum(ynet[y] for y in range(y_start, yy + 1)), 1) for yy in range(y_start, 2027)],
        top=decs[:8],
        led=dict(trade=chbw("trade"), draft=chbw("draft"), waiver=chbw("waiver", 4)),
        allx=ALLX,
        walk=walk[:5],
        dna={k: {t: round(x, 1) for t, x in v.items()} for k, v in dna.items()},
    ))
    print(f"{reg['abbr']}: trades {tr_net:+.1f} | draft {dr_net:+.1f} | waiver {wv_net:+.1f} "
          f"| FA raw {fa_raw:+.1f} (ungraded) | total {total:+.1f} over {seasons} yrs", flush=True)

json.dump(results, open("/work/sweep_results.json", "w"), indent=1)
# v5.5: every decision of each kind, for grading single moves against moves of their size
json.dump(MOVE_POP, open("/work/move_pop_sweep.json", "w"))
print("WROTE sweep_results.json", flush=True)
