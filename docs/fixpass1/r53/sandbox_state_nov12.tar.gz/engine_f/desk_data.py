"""
DEAL DESK data pack: everything the in-page evaluator needs, compact.
Writes desk_data.json:
  players: [name, pid, team abbr (2026 club or prospect org), isPit,
            age2026, w2024, w2025, w2026, ctrlDefault, rank2026]
  curves:  aging curves + pop mean (proj_curves.json)
  market:  dollars-per-win table, control-bucket price ratios + bust rates,
           star-rental rate, unranked prospect EV
  slot:    draft pick slot-expectation anchors
  teams:   {abbr: 2026 win total}
  deals:   compact 1998-2023 archive [yr, ab, ph, ck, po, recv, paid, who, who_pos, gave, gave_pos]
"""
import json, sqlite3, os
from collections import defaultdict

LVM = {int(k): v for k, v in json.load(open("/work/lvm_cache.json")).items() if not k.startswith("__")}
AGES = json.load(open("/work/ages.json"))
POS = json.load(open("/work/positions.json"))
POS.update(json.load(open("/work/positions2.json")))  # canonical primaryPosition refetch (v4.4)
PITPOS = {"RHP", "LHP", "SP", "RP", "P"}
PC = json.load(open("/work/proj_curves.json"))
RM = json.load(open("/work/rental_market.json"))
cfg = json.load(open("/work/regimes.json"))
ABBR_BY_NAME = {}
for r in cfg["regimes"]:
    ABBR_BY_NAME[r["team"]] = r["abbr"]
    for al in cfg["aliases"].get(str(r["teamId"]), []):
        ABBR_BY_NAME[al] = r["abbr"]

RANKS = {}
ORGS = {}
for rr in json.load(open("/work/prospect_ranks.json")):
    if rr["year"] == 2026:          # v5.5: the current list only (a 2025 rank outlived graduation)
        RANKS[str(rr["pid"])] = rr["rank"]
        ORGS[str(rr["pid"])] = rr.get("name")
try:
    porgs = json.load(open("/work/prospect_orgs.json"))
except Exception:
    porgs = {}

BY = {}
for pid, rec in LVM.items():
    d = defaultdict(float)
    last_team = None; last_y = 0
    for (y, tm, v) in rec["rows"]:
        d[y] += v
        if y >= last_y: last_y, last_team = y, tm
    BY[pid] = (dict(d), last_team, rec["name"])

players = []
for pid, (d, last_team, name) in BY.items():
    recent = any(y in d for y in (2024, 2025, 2026))
    ranked = str(pid) in RANKS
    if not (recent or ranked): continue
    mlb_seasons = sum(1 for v in d.values() if abs(v) > 0.05)
    ctrl = max(1, min(6, 6 - mlb_seasons))
    age = 2026 - AGES.get(str(pid), 2000)
    ab = ABBR_BY_NAME.get(last_team or "", "")
    players.append([name, pid, ab, 1 if POS.get(str(pid)) in PITPOS else 0,
                    age if 16 < age < 50 else 27,
                    round(d.get(2024, 0), 1), round(d.get(2025, 0), 1), round(d.get(2026, 0), 1),
                    ctrl, RANKS.get(str(pid), 0), mlb_seasons])  # mlb_seasons moved to idx 11 below
players.sort(key=lambda p: -(abs(p[5]) + abs(p[6]) + abs(p[7])))
# reorder tail fields: durability at index 10 (from pt_fetch.py; 1.0 default),
# true MLB seasons (service proxy, unclamped) at index 11
try:
    DUR = json.load(open("/work/durability.json"))
except Exception:
    DUR = {}
try:
    PT_RAW = json.load(open("/work/playtime.json"))
except Exception:
    PT_RAW = {}
# minor-league role for pitchers with no MLB workload: the prospect model's
# games-started share (pros_peak.json), else the Stats API minor-league
# year-by-year line (cached), else SP for a ranked prospect
_PK_POS = {k: z.get("pos") for k, z in json.load(open("/work/pros_peak.json"))["players"].items()}
_MR_F = "/work/statsapi_cache/milb_role.json"
try: _MILB_ROLE = json.load(open(_MR_F))
except Exception: _MILB_ROLE = {}
def _milb_role(pid, ranked):
    k = str(pid)
    if _PK_POS.get(k) in ("SP", "RP"): return _PK_POS[k]
    if k not in _MILB_ROLE:
        gs = gp = 0
        try:
            import urllib.request as _u
            _d = json.load(_u.urlopen(_u.Request(f"https://statsapi.mlb.com/api/v1/people/{k}/stats?stats=yearByYear&group=pitching&sportIds=11,12,13,14,16&leagueListId=milb_all",
                                                 headers={"User-Agent": "Mozilla/5.0"}), timeout=30))
            sp = [x for st in _d.get("stats", []) for x in st.get("splits", [])]
            yrs = sorted({x.get("season") for x in sp}, reverse=True)[:2]
            for x in sp:
                if x.get("season") in yrs:
                    gs += x["stat"].get("gamesStarted", 0) or 0; gp += x["stat"].get("gamesPlayed", 0) or 0
        except Exception:
            gp = -1
        _MILB_ROLE[k] = [gs, gp]
    gs, gp = _MILB_ROLE[k]
    if gp > 0: return "SP" if gs / gp >= 0.5 else "RP"
    return "SP" if ranked else "RP"
for p in players:
    svc = p.pop(10)                      # mlb_seasons appended during build
    p.append(DUR.get(str(p[1]), 1.0))    # idx 10: durability
    p.append(svc)                        # idx 11: MLB seasons played
    pp = POS.get(str(p[1]))
    p.append("C" if pp == "C" else "IF" if pp in ("1B","2B","3B","SS") else
             "OF" if pp in ("LF","CF","RF","OF","DH") else "SP" if pp == "SP" else
             "RP" if pp == "RP" else "P")   # idx 12: position group
    # idx 13: depth-chart position. RHP/LHP/P resolved SP vs RP by most
    # recent observed workload (IP/G >= 3 = starter); no record -> RP
    raw = pp or ("P" if p[3] else "OF")
    if raw in ("RHP", "LHP", "P", "TWP"):
        rec = PT_RAW.get(str(p[1]), {})
        role = None
        for season in ("2026", "2025", "2024"):
            ip, g = (rec.get(season) or [0, 0, 0])[1], (rec.get(season) or [0, 0, 0])[2]
            if ip > 0 and g > 0: role = "SP" if ip / g >= 3.0 else "RP"; break
        if role is None:
            # v5.9: no MLB workload (a prospect): the minor-league games-started
            # share decides (Seth Hernandez, Ryan Sloan, Thomas White start;
            # the old default tagged every one of them RP)
            role = _milb_role(p[1], bool(p[9]))
        raw = role
    p.append(raw)
    # idx 14: pedigree (v4.4) - best season of the last five, decayed 0.88/yr,
    # so a star coming off a down platform year still reads as a star
    dd = BY[p[1]][0]
    p.append(round(max(dd.get(2026 - k, 0.0) * (0.88 ** k) for k in range(5)), 2))
print("desk players:", len(players), "| with durability:", sum(1 for p in players if p[10] != 1.0))
try: json.dump(_MILB_ROLE, open(_MR_F, "w"))
except Exception: pass

# resolve org for ranked prospects with no MLB track (no value rows -> no team abbr)
import urllib.request as _ur, time as _t
TID2AB_ALL = {r["teamId"]: r["abbr"] for r in cfg["regimes"]}
need = [p for p in players if not p[2] and p[9]]
for i in range(0, len(need), 50):
    chunk = need[i:i+50]
    ids = ",".join(str(p[1]) for p in chunk)
    try:
        d = json.load(_ur.urlopen(f"https://statsapi.mlb.com/api/v1/people?personIds={ids}&hydrate=currentTeam", timeout=40))
        bypid = {pp["id"]: pp.get("currentTeam", {}) for pp in d.get("people", [])}
        for p in chunk:
            ct = bypid.get(p[1], {})
            org = ct.get("parentOrgId") or (ct.get("id") if ct.get("id") in TID2AB_ALL else None)
            if org in TID2AB_ALL: p[2] = TID2AB_ALL[org]
    except Exception as e:
        print("prospect org fetch failed:", e)
    _t.sleep(0.5)
print("prospect orgs resolved:", sum(1 for p in need if p[2]), "of", len(need))

# team 2026 win totals
import urllib.request, time
def get(u, tries=3):
    for a in range(tries):
        try: return json.load(urllib.request.urlopen(urllib.request.Request(u, headers={"User-Agent":"Mozilla/5.0"}), timeout=40))
        except Exception: time.sleep(2+2*a)
    return {}
TID2AB = {r["teamId"]: r["abbr"] for r in cfg["regimes"]}
teams = {}
d = get("https://statsapi.mlb.com/api/v1/standings?leagueId=103,104&season=2026&standingsTypes=regularSeason")
for g in d.get("records", []):
    for t in g.get("teamRecords", []):
        ab = TID2AB.get(t["team"]["id"])
        if ab: teams[ab] = t.get("wins", 81)

# ---- contract book with platform context and realized outcomes ----
import csv, unicodedata, sys
sys.path.insert(0, "/home/claude")
from contracts_recent import RECENT
def norm(nm):
    x = unicodedata.normalize("NFKD", nm or "").encode("ascii", "ignore").decode()
    return x.lower().replace(".", "").replace(" jr", "").strip()
NAME2PIDS = defaultdict(list)
for pid, (d, lt, name) in BY.items():
    NAME2PIDS[norm(name)].append(pid)
TID2AB2 = {r["teamId"]: r["abbr"] for r in cfg["regimes"]}
TEAMNAMES = {r["teamId"]: set(cfg["aliases"].get(str(r["teamId"]), [])) | {r["team"]} for r in cfg["regimes"]}
def short_to_tid(short):
    for r in cfg["regimes"]:
        names = TEAMNAMES[r["teamId"]]
        if any(short and short.lower() in nm.lower() for nm in names):
            return r["teamId"]
    return None
raw_contracts = []
with open("/work/repo/data/contracts_espn.csv") as f:
    for row in csv.DictReader(f):
        tid = short_to_tid(row["to_team"])
        if tid: raw_contracts.append((int(row["offseason"]), row["player"], tid, int(row["years"]), float(row["total_m"]), 0))
AB2TID = {r["abbr"]: r["teamId"] for r in cfg["regimes"]}
for off, pl, ab, yrs, tot in RECENT:
    raw_contracts.append((off, pl, AB2TID[ab], yrs, float(tot), 0))
# extensions (contracts_ext.EXT): big guaranteed money the FA book never sees.
# A spring signing (month <= 3) covers that season (off = year-1); later
# signings start the next season. CBT value used where it diverges (deferrals).
from contracts_ext import EXT
EXT_META = {}   # (off, player, tid) -> (sign month, nominal total when the book carries CBT value)
for _e in EXT:
    dt, pl, ab, yrs, tot, cbt = _e[:6]
    y, m = int(dt[:4]), int(dt[5:7])
    off = (_e[6] - 1) if len(_e) > 6 else (y - 1 if m <= 3 else y)
    if ab in AB2TID:
        EXT_META[(off, pl, AB2TID[ab])] = (dt, float(tot) if cbt else None)
        raw_contracts.append((off, pl, AB2TID[ab], yrs, float(cbt if cbt else tot), 1))
# v5.9: resolve by name AND club, era and career stage (pid_resolve.py, the
# same resolver the engine book uses); the old join kept the namesake with
# the most WAR, so the Dodgers' catcher carried LHP Will Smith's deals
from pid_resolve import Resolver as _Resolver
_RES = _Resolver(LVM, extra=[(p[0], p[1]) for p in players])
_TID2AB_B = {r["teamId"]: r["abbr"] for r in cfg["regimes"]}
book = []
_seen_k = set()
try:
    _PPL0 = json.load(open("/work/statsapi_cache/people.json"))
except Exception:
    _PPL0 = {}
def _birth_year(pid):
    if str(pid) in AGES: return AGES[str(pid)]
    b = (_PPL0.get(str(pid)) or {}).get("birth") or ""
    return int(b[:4]) if b else 0
# an extension listed again as a free-agent signing (same player, club,
# season, terms): the extension row stands
_ext_k = set()
for (off, pl, tid, yrs, tot, typ) in raw_contracts:
    if typ == 1:
        _p = _RES.resolve(pl, _TID2AB_B.get(tid), off + 1, "ext", yrs)
        if _p: _ext_k.add((_p, off, tid, yrs, round(tot, 1)))
for (off, pl, tid, yrs, tot, typ) in raw_contracts:
    pid = _RES.resolve(pl, _TID2AB_B.get(tid), off + 1, "fa" if typ == 0 else "ext", yrs)
    if pid is None: continue
    # one contract, one row: the same deal listed as both a free-agent signing
    # and an extension (Escobar ARI 2018, Wacha KC 2024) keeps the first source
    _k = (pid, off, tid, yrs, round(tot, 1))
    if _k in _seen_k or (typ == 0 and _k in _ext_k): continue
    _seen_k.add(_k)
    d = BY[pid][0] if pid in BY else {}
    plat1 = round(d.get(off, 0), 1)             # platform season
    plat2 = round(d.get(off - 1, 0), 1)         # season before
    age = off - _birth_year(pid)
    if not (18 < age < 46): continue
    names = TEAMNAMES.get(tid, set())
    elapsed = min(yrs, 2026 - off)
    realized = round(sum(v for (y, tm, v) in (LVM.get(pid) or {"rows": []})["rows"]
                         if off + 1 <= y <= off + elapsed and tm in names), 1) if elapsed > 0 else None
    pit = 1 if POS.get(str(pid)) in PITPOS else 0
    pgroup = (lambda p: "C" if p == "C" else "IF" if p in ("1B","2B","3B","SS") else
              "OF" if p in ("LF","CF","RF","OF","DH") else "SP" if p == "SP" else
              "RP" if p == "RP" else "P")(POS.get(str(pid)))
    book.append([pl, off, TID2AB2.get(tid, ""), yrs, round(tot, 1), age, pit, plat1, plat2,
                 realized if realized is not None else "", elapsed, pid, typ, pgroup])
    if typ == 1:
        dt, nom = EXT_META.get((off, pl, tid), (None, None))
        # idx14: nominal total when the book prices the CBT value; idx15: sign month
        book[-1] += [nom, (dt + "-15") if dt and len(dt) == 7 else None]
print("contract book rows matched:", len(book), "of", len(raw_contracts))

# ---- 2026-27 winter reality pass (curated, Nov 2026) ----
# Opt-outs and declined options void remaining coverage: these players ARE in
# the 2026-27 class although a book row runs past 2026. Rows keep their
# original terms (comps stay honest); the page excludes these pids from
# forward coverage and this script excludes their 2027+ money from payroll.
FA27_NAMES = {"Michael King", "Clay Holmes", "Shota Imanaga"}
fa27 = sorted({row[11] for row in book if row[0] in FA27_NAMES})

# Service time (v5.1): real MLB service reconstructed from each player's
# transaction history (svc_fetch.py -> service.json, years.days as a float),
# replacing the seasons-with-an-appearance proxy that counted a September
# call-up as a full year. idx 11 = service through 2026; idx 8 = seasons of
# control left; idx 15 = arbitration awards already received before 2026's
# winter (Super Two included), so the page knows which arb year comes next.
SVC = json.load(open("/work/service.json")) if __import__("os").path.exists("/work/service.json") else {}
# free by contract expiry rather than six-year service (NPB signees whose
# original deals ran out): encoded as FA-eligible
CONTRACT_FA = {"Seiya Suzuki", "Shota Imanaga"}
import math as _m
n_svc = 0
for p in players:
    sv = SVC.get(str(p[1]))
    if p[0] in CONTRACT_FA:
        p[11] = 6.0
    elif sv:
        p[11] = sv["svc"]; n_svc += 1
    p[8] = max(1, min(6, 6 - int(_m.floor(p[11] + 1e-9))))
    p.append(len([w for w in (sv or {}).get("arb_winters", []) if w < 2026]))   # idx 15

# ---- v5.8 projection base (idx 16) and availability flag (idx 17) ----
# Rate x playing time, Marcel-style: WAR per PA (hitters) or per IP
# (pitchers) over 2024-26 weighted 5/4/3, regressed toward the role's
# league rate by adding K weighted units of league-average playing time,
# times expected 2027 playing time (the same weights over every season since
# his debut, a missed season counting as zero, capped at a full season).
# Missed time is counted once, here; the page no longer multiplies by the
# durability factor on top. Two straight seasons with no MLB time:
# projection withheld (idx 17 = 1) and priced at zero.
# Nov 9: weights 5/3/2 and 1.5x the regression (proj_bt.py: walk-forward on
# every player-season 2016-2026, 8,696 rows; rate RMSE 1.130 -> 1.117 with
# actual playing time, 1.408 -> 1.389 with expected playing time; after a
# big drop or jump the same weights still win, with little bias)
_W = {2026: 5, 2025: 3, 2024: 2}
_CAP = {"bat": 680.0, "SP": 195.0, "RP": 75.0}
_K = {"bat": 1800.0, "SP": 900.0, "RP": 675.0}
def _role(p):
    if not p[3]: return "bat"
    return "SP" if p[13] == "SP" else "RP"
def _pt(rec, y, role):
    r = (rec or {}).get(str(y)) or [0, 0, 0]
    return float(r[0] if role == "bat" else r[1])
PTX = {}
# Nov 9 (pt_model.py): hitters' expected playing time from a ridge fit, walk-forward 2016-26,
# on the last three seasons' PA, games played, PA per healthy team game (injured-list days from
# the transaction sweep), the regressed WAR rate, age and the formula below. PA RMSE 176.9 ->
# 157.4, WAR RMSE 1.541 -> 1.532; role-drop group bias +100 -> +11 PA, 31+ +78 -> +9.
# Covers hitters 37 or younger with 150+ PA in 2026 or 300+ in 2025; the formula covers the rest.
try:
    PTM = json.load(open("/work/pt_model.json")).get("p27", {})
except Exception:
    PTM = {}
_acc = {"bat": [0.0, 0.0], "SP": [0.0, 0.0], "RP": [0.0, 0.0]}
for p in players:
    rec = PT_RAW.get(str(p[1])); role = _role(p)
    for y, idx in ((2024, 5), (2025, 6), (2026, 7)):
        pt = _pt(rec, y, role)
        if pt > 0: _acc[role][0] += p[idx]; _acc[role][1] += pt
POP_RATE = {k: (a[0] / a[1] if a[1] else 0.0) for k, a in _acc.items()}
print("league WAR rate by role (per PA / per IP):", {k: round(v, 5) for k, v in POP_RATE.items()})
for p in players:
    rec = PT_RAW.get(str(p[1])); role = _role(p)
    debut = min(BY[p[1]][0]) if BY.get(p[1]) and BY[p[1]][0] else 2026
    if not rec:
        p.append(None); p.append(0); continue          # no playing-time record: old formula on the page
    num = den = 0.0; ptw = ptd = 0.0; pts = []
    for y, idx in ((2024, 5), (2025, 6), (2026, 7)):
        if y < debut: continue
        pt = _pt(rec, y, role); w = _W[y]
        ptw += w * pt; ptd += w; pts.append(pt)
        if pt > 0: num += w * p[idx]; den += w * pt
    if ptd == 0: p.append(None); p.append(0); continue
    rate = (num + _K[role] * POP_RATE[role]) / (den + _K[role])
    # expected playing time: 60% the average of his two fullest recent
    # seasons, 40% the weighted line with missed time at zero (a single short
    # season is partly a one-off; repeated ones are not)
    top2 = sorted(pts, reverse=True)[:2]
    # Nov 9 (pt_bt.py, walk-forward 2016-26): at 28 and older the latest
    # seasons say more about the role than the two fullest ones (a regular
    # turning bench player): 20% top-two, 80% weighted (RMSE 1.319 -> 1.310,
    # bias +0.02 -> -0.01); 27 and under keep 60/40
    # one injury season after full ones (last under half a season, one of
    # the two before at 80%+) rebounds more: 40% there (bias +0.12 at 60%,
    # -0.08 at 20%, +0.02 at 40%)
    _l = _pt(rec, 2026, role); _p2 = max(_pt(rec, 2025, role), _pt(rec, 2024, role))
    _inj = _l < 0.5 * _CAP[role] and _p2 >= 0.8 * _CAP[role]
    _a = 0.6 if p[4] <= 26 else 0.4 if _inj else 0.2
    pt_exp = min(_a * (sum(top2) / len(top2)) + (1 - _a) * (ptw / ptd), _CAP[role])
    # v6.0 (audit, Nov 3): young players only (27 or under in 2027). Walk-forward
    # PT backtest 2012-25 (age <= 27): the formula above ran short for a
    # partial debut season followed by a full one (SP -13.7 IP, hitters -91 PA)
    # and for a healthy season after missed time (SP -20.5 IP, hitters -88 PA).
    # Two fixes, both reduce PT and WAR error there and leave other players
    # unchanged; at 28+ the floor made WAR error worse, hence the age guard.
    #  (a) a partial debut season (under half a full season) before 2026 is not
    #      missed time when a later season reached half a full season: drop it
    #      from the playing-time average (the rate above still uses it)
    #  (b) floor: a 2026 season of at least 60% of a full one sets expected
    #      playing time to at least 85% of it
    if p[4] <= 26:
        _ys = [y for y in (2024, 2025, 2026) if y >= debut]
        _full_later = any(_pt(rec, y, role) >= 0.5 * _CAP[role] for y in _ys if y > debut)
        if debut in _ys and debut < 2026 and _full_later and _pt(rec, debut, role) < 0.5 * _CAP[role]:
            _k = [y for y in _ys if y != debut]
            _pk = [_pt(rec, y, role) for y in _k]
            _t2 = sorted(_pk, reverse=True)[:2]
            pt_exp = min(0.6 * (sum(_t2) / len(_t2)) + 0.4 * sum(_W[y] * _pt(rec, y, role) for y in _k) / sum(_W[y] for y in _k), _CAP[role])
        _last = _pt(rec, 2026, role)
        if _last >= 0.6 * _CAP[role]:
            pt_exp = min(max(pt_exp, 0.85 * _last), _CAP[role])
    # Nov 9 (pt_war_bt2.py, pt_war_bt3.py, pt_pit_bt.py; hitters and starters
    # 27 and older in 2027, walk-forward 2016-26): the formula above still ran
    # high for established players. Hitters coming off 300+ PA got 7-25% less
    # than it said, more when older and when they had hit poorly (under 1
    # WAR per 600, 75% of the estimate; stars 91%); full-timers came in 100
    # PA under, part-timers 130 over. Starters the same shape (+30 IP for
    # full-time 27+). Two steps, both only for 27+: regress expected playing
    # time 15% toward half a season, then cut it for weak recent performance,
    # never raise it. Hitters: WAR RMSE 1.661 -> 1.637 (1.632 with the
    # steeper aging decline), 31-34 bias +0.43 -> +0.18. Starters: 1.379 ->
    # 1.359 at 27+, full-time bias +0.34 -> +0.13. Relievers: no gain, unchanged.
    if p[4] >= 26 and role in ("bat", "SP"):
        _mid = 350.0 if role == "bat" else 0.5 * _CAP[role]
        _pe0 = pt_exp
        pt_exp = 0.85 * pt_exp + 0.15 * _mid
        _full = rate * (600.0 if role == "bat" else _CAP[role])   # WAR per 600 PA / per full starter season, as tested
        _m, _c, _lo, _thr = (3.5, 0.12, 0.7, 300.0) if role == "bat" else (3.0, 0.10, 0.75, 0.45 * _CAP[role])
        if _pe0 >= _thr:
            pt_exp *= max(_lo, min(1.0, 1 + _c * (_full - _m)))
        # Nov 9 (pt_floor_bt.py, pt_floor_sp.py): a regular who became one
        # last year (full 2026, partial seasons before) kept playing: that
        # group got 25% MORE than the cut above said (hitters n 111, ratio
        # 1.25; starters 1.10). Floor at a share of last season when it was
        # at least 75% of a full one: hitters 0.75 (bias -90 -> -18 PA,
        # 27+ RMSE unchanged), starters 0.70 (-10.7 -> +0.9 IP).
        _last = _pt(rec, 2026, role)
        if _last >= 0.75 * _CAP[role]:
            pt_exp = min(_CAP[role], max(pt_exp, (0.75 if role == "bat" else 0.70) * _last))
    if role == "bat" and str(p[1]) in PTM:
        pt_exp = min(_CAP[role], float(PTM[str(p[1])]))
    missed = debut <= 2025 and _pt(rec, 2025, role) == 0 and _pt(rec, 2026, role) == 0
    if missed: p.append(0.0); p.append(1); continue
    base = rate * pt_exp
    # Nov 10 2026, prime-age regulars. Walk-forward 2016-2026: hitters 30 and under projected for 2.5 to 4.25
    # wins beat the projection by 0.36 (se 0.11) in year one and 0.30 in year two, in every period block;
    # hitters 31 and over did not, and starters showed nothing reliable. A quarter win across a year-one
    # projection of 2.75 to 4.0, fading to nothing at 2.0 and 4.75 (y1_split.py, y1_bump.py).
    if role == "bat" and p[4] + 1 <= 30:
        _y1 = base + PC["curves"]["bat"].get(str(min(max(p[4] + 1, 20), 41)), -0.3)
        base += 0.25 * max(0.0, min(1.0, (_y1 - 2.0) / 0.75, (4.75 - _y1) / 0.75))
    p.append(round(base, 2)); p.append(0)
    PTX[p[1]] = round(pt_exp) if role == "bat" else round(pt_exp, 1)   # Nov 9: expected 2027 PA / IP, shown beside the projection
print("service from transactions:", n_svc, "| contract-expiry FAs:", len(CONTRACT_FA))


# ---- Nov 9: published arbitration projections (MLB Trade Rumors, Matt Swartz's model) ----
# On the 48 real 2026 awards our WAR-based estimate missed by ~$1.6M a player (leave-one-out);
# MLBTR's 2026 projections missed the same awards by $0.49M (MAE), RMSE $0.71M. The 2027 award
# is theirs where they list the player; later awards scale our estimate by his ratio to theirs.
ARB27 = {}
try:
    _ab = {v: k for k, v in ABBR_BY_NAME.items()}
    _byn = {}
    for _p in players: _byn.setdefault(norm(_p[0]), []).append(_p)
    _miss = []
    for _o in json.load(open("/work/arb_mlbtr_2027.json")):
        _c = _byn.get(norm(_o["name"].replace("\u2019", "'")), [])
        _t = ABBR_BY_NAME.get(_o["team"], "")
        _c2 = [x for x in _c if x[2] == _t] or _c
        if len(_c2) == 1: ARB27[str(_c2[0][1])] = _o["aav"]
        else: _miss.append(_o["name"])
    print("MLBTR arbitration projections matched:", len(ARB27), "| unmatched:", _miss[:12])
except FileNotFoundError:
    pass

# ---- v5.2: the winter as it actually happened (winter_2026.py) ----
import winter_2026 as W
PBYNAME = {}
for p in players: PBYNAME.setdefault(norm(p[0]), p)
def P_(nm):
    p = PBYNAME.get(norm(nm))
    if p is None: print("  winter: no desk row for", nm)
    return p
def proj27(p):
    """mirror of the page's dkBase + one aging step (dkProjSeasons per[0])"""
    obs = [(v, w) for v, w in ((p[7], 5), (p[6], 3), (p[5], 2)) if abs(v) > 0.05]
    base = (0.85 * sum(v * w for v, w in obs) / sum(w for _, w in obs) + 0.15 * PC["pop_mean"]) if obs else PC["pop_mean"]
    cv = PC["curves"]["pit" if p[3] else "bat"]
    return max(base + cv.get(str(min(max(p[4] + 1, 20), 41)), -0.3), 0) * (p[10] or 1)
STATUS = {}
# 1. posted players: a translated line (posted_build.py) on a normal row
POSTED = json.load(open("/work/posted.json"))
for spid, z in POSTED.items():
    pid = int(spid)
    if any(p[1] == pid for p in players): continue
    t = z["translated"]
    pos = z["pos"]; grp = "SP" if pos == "SP" else "RP" if pos == "RP" else "C" if pos == "C" else \
        "IF" if pos in ("1B", "2B", "3B", "SS") else "OF"
    row = [z["name"], pid, "", z["pit"], z["age"], t.get("2024", 0), t.get("2025", 0), t.get("2026", 0),
           6, 0, 1.0, 0.0, grp, pos, round(max(t.get(str(2026 - k), 0) * (0.88 ** k) for k in range(3)), 2), 0]
    players.append(row)
    club, lg, dl = W.POSTED[pid]
    STATUS[pid] = ["posted", f"announced for posting by the {club} ({lg}); if posted Nov 1 as expected, sign by {dl}"]   # v5.8: the window opens when the posting is official
# 1b. prospects, Phase II (prospects_peak.py): minor-league translations plus
# 100 nearest 2012-2019 comparables on age, level, translated rates,
# position and pedigree. Every prospect carries a peak projection; org
# prospects beyond the Top 100 are VALUED by their comps' six-season WAR
# (Top 100 value stays on the rank curve, which the backtest still favors)
PK = json.load(open("/work/pros_peak.json"))
PROS = json.load(open("/work/pros.json"))     # rookie table, Top 100 levels (v5.2)
PROS_OUT, PEAK = {}, {}
have = {p[1]: p for p in players}
ranked_now = {p[1] for p in players if p[9]}
byorg = defaultdict(list)
for spid, z in PK["players"].items():
    pid = int(spid)
    if z["rank"] or pid in ranked_now or not z["org"] or z["age"] > 26: continue
    p = have.get(pid)
    if p is not None and (abs(p[5]) + abs(p[6]) + abs(p[7]) >= 0.6): continue
    byorg[z["org"]].append((z["ev6d"], spid))
n_new = 0
for ab, xs in byorg.items():
    # each club: its 25 best by value, plus its 10 highest ceilings not already
    # in (teenagers in the complex leagues price low on six discounted years
    # but are exactly who gets asked for in trades)
    top = [sp for _, sp in sorted(xs, reverse=True)[:25]]
    ceil = [sp for sp in sorted((sp for _, sp in xs), key=lambda sp: -PK["players"][sp]["peak"]) if sp not in top][:10]
    xs_sorted = sorted(((PK["players"][sp]["ev6d"], sp) for sp in top + ceil), reverse=True)
    for k, (_, spid) in enumerate(xs_sorted):
        z = PK["players"][spid]; pid = int(spid)
        pos = z["pos"]
        if pid not in have:
            grp = "SP" if pos == "SP" else "RP" if pos == "RP" else "C" if pos == "C" else \
                "IF" if pos in ("1B", "2B", "3B", "SS") else "OF"
            dpos = pos if pos in ("C", "1B", "2B", "3B", "SS", "LF", "CF", "RF", "SP", "RP") else "OF"
            row = [z["name"], pid, ab, 1 if z["kind"] == "P" else 0, z["age"], 0, 0, 0, 6, 0, 1.0, 0.0, grp, dpos, 0, 0]
            players.append(row); have[pid] = row; n_new += 1
        elif not have[pid][2]: have[pid][2] = ab
        PROS_OUT[spid] = [z["lvl"], z["ev6d"], z["y1"], z["line"], k + 1, None]
# Nov 2026: a Top 100 prospect with no row yet (no Ledger record at all) still
# belongs on the board, valued on the rank curve like every ranked prospect
for _spid, _rk in RANKS.items():
    _pid = int(_spid)
    if _pid in have: continue
    _z = PK["players"].get(_spid)
    if not _z or not _z.get("org"): continue
    _pos = _z["pos"]
    _grp = "SP" if _pos == "SP" else "RP" if _pos == "RP" else "C" if _pos == "C" else \
        "IF" if _pos in ("1B", "2B", "3B", "SS") else "OF"
    _dpos = _pos if _pos in ("C", "1B", "2B", "3B", "SS", "LF", "CF", "RF", "SP", "RP") else ("SP" if _z["kind"] == "P" else "OF")
    _row = [_z["name"], _pid, _z["org"], 1 if _z["kind"] == "P" else 0, _z["age"], 0, 0, 0, 6, _rk, 1.0, 0.0, _grp, _dpos, 0, 0]
    players.append(_row); have[_pid] = _row
    print("  Top 100 row added:", _z["name"], _rk, _z["org"])
# ---- v5.9 currency pass: every desk row's club comes from the Stats API ----
# The value cache knows the last club a player APPEARED for, so a player
# traded, claimed or released without playing for his new club stayed with
# the old one (Blake Perkins on MIL after his Aug 1 trade to CLE, Richard
# Fitts on BOS after the Sonny Gray deal). currentTeam (mapped to its parent
# organization) is the club that holds him today; a free agent keeps the
# club he left. People records are cached in statsapi_cache/people.json.
import tx_refresh as _TXR, os as _os, datetime as _dtm
_PPL_F = "/work/statsapi_cache/people.json"
try:
    PEOPLE = json.load(open(_PPL_F))
except Exception:
    PEOPLE = {}
_need = [p[1] for p in players if str(p[1]) not in PEOPLE or PEOPLE.get("__asof") != _dtm.date.today().isoformat()]
if _need:
    _fresh = _TXR.fetch_people(_need)
    if _fresh:
        PEOPLE.update(_fresh); PEOPLE["__asof"] = _dtm.date.today().isoformat()
        json.dump(PEOPLE, open(_PPL_F, "w"))
_moved = 0
for p in players:
    rec = PEOPLE.get(str(p[1])) or {}
    org = rec.get("team") if rec.get("team") in TID2AB_ALL else rec.get("parent")
    ab = TID2AB_ALL.get(org)
    if ab and ab != p[2]:
        _moved += 1; p[2] = ab
print("currency pass: clubs refreshed from statsapi currentTeam:", _moved)

# org slot follows the club he is with now (v5.4: a prospect moved since the
# minor-league season read the old system's slot, so two players shared CHC #19)
_byclub = defaultdict(list)
for spid, v in PROS_OUT.items():
    _byclub[have[int(spid)][2]].append((v[1], spid))
for ab, xs in _byclub.items():
    for k, (_, spid) in enumerate(sorted(xs, reverse=True)):
        PROS_OUT[spid][4] = k + 1
for spid, z in PK["players"].items():
    if int(spid) in have:
        PEAK[spid] = [z["peak"], z["p2"], z["p4"], z["up"], z["y1"], z["lvl"], z["line"],
                      [[c[0], c[1], c[4]] for c in z["comps"][:6]], z.get("traj")]
print("prospects: org tier", len(PROS_OUT), "| new desk rows:", n_new, "| peak projections on desk rows:", len(PEAK))
# 2. filed for free agency: every filing in the league feed since Oct 1
DECL = {}
fd = get("https://statsapi.mlb.com/api/v1/transactions?startDate=2026-10-01&endDate=2026-11-30")
for t in fd.get("transactions", []):
    if t.get("typeDesc") == "Declared Free Agency" and (t.get("person") or {}).get("id"):
        DECL[t["person"]["id"]] = t.get("date")
if not DECL:      # feed unreachable: fall back to the Nov 1 snapshot
    DECL = {int(k): "2026-10-29" for k in json.load(open("/work/fa_declared_2026.json"))}
json.dump({str(k): v for k, v in DECL.items()}, open("/work/fa_declared_2026.json.tmp", "w"))
byid = {p[1]: p for p in players}
for pid, d in DECL.items():
    if pid in byid:
        import datetime as _dt
        _d = _dt.date.fromisoformat(d[:10])
        STATUS[pid] = ["fa", f"filed {_d.strftime('%b')} {_d.day}"]
for nm, why in W.FA.items():
    p = P_(nm)
    if p: STATUS[p[1]] = ["fa", why]
for nm in W.CONTROLLED_AFTER_DECLINE:
    p = P_(nm)
    if p: STATUS[p[1]] = ["ctr", "club option declined; still under club control through arbitration"]
# 3. contracts the base book lacks (typ 2: on file, never a pricing comp)
def add_contract(p, ab, y0, y1, aav, label):
    yrs = y1 - y0 + 1
    # v5.9: a deal the base book already carries (Shelby Miller's 2 yr Cubs
    # deal, Torrens' extension) gets its status label but no second row
    if any(r[11] == p[1] and r[12] != 2 and r[1] + 1 <= y0 and r[1] + r[3] >= y1 for r in book): return
    book.append([p[0], y0 - 1, ab, yrs, round(aav * yrs, 2), y0 - 1 - AGES.get(str(p[1]), 2000), p[3],
                 p[7], p[6], "", 0, p[1], 2, p[12], label])
for nm, ab, y0, y1, aav, label in W.CONTRACTS:
    p = P_(nm)
    if p:
        add_contract(p, ab, y0, y1, aav, label)
        STATUS[p[1]] = ["ctr", label]
# 4. open decisions (due Nov 2), modeled by each side's own arithmetic
for nm, kind, amt, buy in W.PENDING:
    p = P_(nm)
    if not p: continue
    vet = p[11] >= 6
    if kind == "club":
        val = proj27(p) * 10.0
        keep = val >= amt - buy
        has_row = any(r[11] == p[1] and r[1] + r[3] >= 2027 for r in book)
        txt = f"${amt:g}M club option, decision due Nov 2; the Ledger models it {'exercised' if keep else 'declined'} (projected 2027 value ${val:.1f}M vs ${amt - buy:g}M net of the buyout)"
        if keep:
            if not has_row: add_contract(p, p[2], 2027, 2027, amt, f"${amt:g}M club option (modeled exercised)")
            STATUS[p[1]] = ["pendin", txt]
        else:
            # declined: a veteran is a free agent; a younger player stays under control at an arbitration salary
            if has_row: fa27.append(p[1])
            STATUS[p[1]] = ["pendfa" if vet else "pendin", txt + ("" if vet else "; he stays under club control")]
    elif kind == "mutual":
        STATUS[p[1]] = ["pendfa" if vet else "pendin",
                        f"mutual option open (decision due Nov 2); mutual options are almost never exercised by both sides" +
                        ("" if vet else "; he is under club control either way")]
    else:
        STATUS[p[1]] = ["pendin", "opt-out decision due Nov 2; modeled as staying (the money left beats his projected market)"]
for nm, why in W.OUT.items():
    p = P_(nm)
    if p: STATUS[p[1]] = ["out", why]
# ---- v5.9 currency pass: availability from the league transaction feed ----
# (statsapi transactions Jan 2025 - today, statsapi_cache/tx.json).
#  - restricted or ineligible list with no activation for 60+ days: out
#    (Luis L. Ortiz, the Clase case, since Jul 3 2025)
#  - retired with no later signing: out (Rizzo Sep 13 2025, Mancini Sep 19 2026)
#  - elected free agency or released since Oct 1 2025 with no later signing: fa
#  - no 2026 MLB game at 36 or older (or an inactive people record) with no
#    contract into 2027: out, so long-gone veterans leave the free-agent
#    board (Charlie Morton, Rich Hill, Yuli Gurriel)
try:
    _TX = json.load(open("/work/statsapi_cache/tx.json"))
    if _TX.get("asof") != _dtm.date.today().isoformat(): raise ValueError("stale")
    _TX = _TX["tx"]
except Exception:
    try: _TX = _TXR.fetch_tx()
    except BaseException: _TX = json.load(open("/work/statsapi_cache/tx.json"))["tx"]
_ev = defaultdict(list)
_desk_ids = {p[1] for p in players}
for t in _TX:
    pid = (t.get("person") or {}).get("id")
    if pid not in _desk_ids: continue
    _ev[pid].append((t.get("date", ""), t.get("id", 0), t.get("typeDesc", ""), t.get("description") or "",
                     (t.get("toTeam") or {}).get("name", ""), (t.get("fromTeam") or {}).get("name", "")))
_today = _dtm.date.today()
def _fmt(d):
    x = _dtm.date.fromisoformat(d[:10]); return f"{x.strftime('%b')} {x.day}, {x.year}"
_book_2027 = {r[11] for r in book if r[1] + r[3] >= 2027}
_cur_n = defaultdict(int)
for p in players:
    pid = p[1]
    evs = sorted(_ev.get(pid, []))
    restricted = retired = freed = last_join = None
    for d, _, ty, desc, to_, fr_ in evs:
        l = desc.lower()
        if ("restricted list" in l or "ineligible list" in l) and "placed" in l: restricted = (d, "restricted" if "restricted" in l else "ineligible")
        elif restricted and d > restricted[0] and ty != "Number Change" and "roster status changed" not in l:
            restricted = None                 # activated, released, assigned, traded: back in play
        if ty == "Retired": retired = d
        if ty in ("Declared Free Agency", "Released") and d >= "2025-10-01": freed = (d, ty, desc)
        if ty in ("Signed as Free Agent", "Trade", "Claimed Off Waivers", "Rule 5 Selection", "Purchase",
                  "Contract Purchased", "Acquired", "Obtained"):
            freed = None                      # a later signing or trade puts him back on a club
            if retired and d > retired: retired = None
            last_join = (d, ty, desc)
        if ty in ("Selected", "Contract Purchased", "Purchase"): last_join = (d, ty, desc)
    # the people record's open roster entry settles what the feed leaves
    # vague (Profar: "roster status changed" Mar 6 2026 = restricted list)
    for _st, _since in (PEOPLE.get(str(pid)) or {}).get("lists") or []:
        if _since and (not restricted or _since[:10] > restricted[0]) and not any(e[0] > _since[:10] and e[2] in ("Released", "Trade", "Signed as Free Agent", "Declared Free Agency") for e in evs):
            restricted = (_since[:10], "restricted" if "restricted" in _st.lower() else "ineligible" if "ineligible" in _st.lower() else "suspended")
    cur = STATUS.get(pid)
    if restricted and (_today - _dtm.date.fromisoformat(restricted[0][:10])).days >= 60:
        if not cur or cur[0] != "out":
            STATUS[pid] = ["out", f"on the {restricted[1]} list since {_fmt(restricted[0])}; not modeled as available"]
            _cur_n["restricted"] += 1
        continue
    if retired:
        if not cur or cur[0] != "out":
            STATUS[pid] = ["out", f"retired {_fmt(retired)}"]; _cur_n["retired"] += 1
        continue
    if cur and cur[0] not in ("fa", "pendfa"): continue
    rec = PEOPLE.get(str(pid)) or {}
    played26 = abs(p[7]) > 0.05 or any(x > 0 for x in ((PT_RAW.get(str(pid)) or {}).get("2026") or [0, 0, 0]))
    has_mlb = (p[11] or 0) > 0 or abs(p[5]) + abs(p[6]) > 0.05
    if has_mlb and not played26 and pid not in _book_2027 and (p[4] >= 36 or rec.get("active") is False):
        why = f"did not play in MLB in 2026 (age {p[4]})" if p[4] >= 36 else "did not play in MLB in 2026 (inactive)"
        if cur: why = "filed for free agency, but " + why
        STATUS[pid] = ["out", why + "; not modeled as available or on the free-agent board"]; _cur_n["inactive"] += 1
        continue
    if cur: continue
    if freed:
        d, ty, desc = freed
        _who = None
        for _r0 in cfg["regimes"]:
            if desc.startswith(_r0["team"]) or any(desc.startswith(a) for a in cfg["aliases"].get(str(_r0["teamId"]), [])): _who = _r0["abbr"]
        verb = "released" if ty == "Released" else "elected free agency"
        STATUS[pid] = ["fa", f"{verb}{(' by ' + _who) if (_who and ty == 'Released') else ''} {_fmt(d)}; unsigned"]
        _cur_n["fa"] += 1
        continue
    # a veteran's in-season minor-league contract, never selected to the
    # 40-man roster, runs out with the season: a free agent this winter, not
    # a controlled player of that organization (Eric Haase, Germán Márquez)
    if (last_join and last_join[1] == "Signed as Free Agent" and "minor league" in last_join[2].lower()
            and last_join[0] >= "2026-03-01" and (p[11] or 0) >= 3):
        _who = (last_join[2].split(" signed ")[0]).strip()
        STATUS[pid] = ["fa", f"minor-league contract with the {_who} (signed {_fmt(last_join[0])}) ended with the season"]
        _cur_n["fa_minor"] += 1
print("currency pass statuses:", dict(_cur_n))
# any free agent whose book row runs past 2026 is voided from 2027 on
cover27 = {r[11] for r in book if r[1] + r[3] >= 2027 and r[12] != 2}
for pid, (code, _) in STATUS.items():
    if code in ("fa", "pendfa") and pid in cover27 and pid not in fa27: fa27.append(pid)
fa27 = sorted(set(fa27))
for k in list(PROS_OUT):
    if STATUS.get(int(k), [None])[0] in ("fa", "out", "pendfa"): del PROS_OUT[k]
# QO eligibility: a player who changed clubs after Opening Day (trade, waiver
# claim, in-season signing) cannot receive a qualifying offer
_con = sqlite3.connect("/work/ledger.sqlite")
QO_INELIG = sorted({int(r[0]) for r in _con.execute(
    "select distinct person_id from sweep_tx where date>='2026-03-26' and date<='2026-10-31' "
    "and person_id is not null and (type_desc in ('Trade','Claimed Off Waivers') "
    "or (type_desc='Signed as Free Agent' and description not like '%minor league%'))")})
for nm in W.PRIOR_QO:
    p = P_(nm)
    if p and p[1] not in QO_INELIG: QO_INELIG.append(p[1])
QO_INELIG = sorted(set(QO_INELIG) & {p[1] for p in players})
print("QO-ineligible (moved in season):", len(QO_INELIG))
import collections as _c
print("winter status:", dict(_c.Counter(v[0] for v in STATUS.values())), "| on-file contracts:", sum(1 for r in book if r[12] == 2))
print("winter reality: fa27 pids", fa27)

# ---- committed payroll per club per season (book contracts, AAV spread) ----
# v5.1: money follows the PLAYER (a traded star's deal sits on his current
# club, not the club that signed him), and a newer contract supersedes an
# older one for the seasons both cover (an extension replaces the deal it
# tore up; a player who signed elsewhere is not on two payrolls). Cash sent
# in trades is not modeled.
CUR = {p[1]: p[2] for p in players}
FA27SET = set(fa27)
OUTSET = {pid for pid, v in STATUS.items() if v[0] == "out"}
by_pid = {}
for row in book:
    by_pid.setdefault(row[11], []).append(row)
payroll = {}
for pid, rows in by_pid.items():
    if pid in OUTSET: continue
    rows = sorted(rows, key=lambda r: (r[1], r[12] == 2))
    for season in range(2026, 2032):
        cover = [r for r in rows if max(2026, r[1] + 1) <= season <= r[1] + r[3]]
        if not cover: continue
        r = cover[-1]                       # the most recent contract governs the season
        if pid in FA27SET and season >= 2027: continue   # opted out / declined / free agent
        ab = CUR.get(pid) or r[2]
        if not ab: continue
        aav = r[4] / r[3]
        payroll.setdefault(ab, {}).setdefault(str(season), [0.0, 0])
        payroll[ab][str(season)][0] += aav
        payroll[ab][str(season)][1] += 1
payroll = {ab: {s: [round(v, 1), n] for s, (v, n) in yrsmap.items()} for ab, yrsmap in payroll.items()}
print("payroll clubs:", len(payroll), "| NYM 2027:", payroll.get("NYM", {}).get("2027"))

deals = json.load(open("/work/deal_archive.json"))
compact = [[x["yr"], x["ab"], x["ph"][0], x["ck"], x.get("po", "mid")[0], x["recv"], x["paid"], x["who"][:24], x.get("wpos", ""), (x.get("gave") or "")[:24], x.get("gpos", "")] for x in deals]

# ---- v5.8: the 2026 draft class (signed picks in the top 100) ----
# MLB Stats API draft endpoint; valued on the draft-slot curve until public
# rankings absorb them (the Big Boards say so)
DRAFT26 = {}
try:
    _d = get("https://statsapi.mlb.com/api/v1/draft/2026")
    _have = {p[1] for p in players}
    _n2ab = {}
    for _r in cfg["regimes"]:
        for _nm in set(cfg["aliases"].get(str(_r["teamId"]), [])) | {_r["team"]}: _n2ab[_nm] = _r["abbr"]
    for _rd in _d.get("drafts", {}).get("rounds", []):
        for _pk in _rd.get("picks", []):
            _num = _pk.get("pickNumber") or 999
            _per = _pk.get("person") or {}
            if _num > 100 or not _per.get("id") or not _pk.get("signingBonus"): continue
            _pid = int(_per["id"]); _ab = _n2ab.get((_pk.get("team") or {}).get("name", ""), "")
            if not _ab: continue
            DRAFT26[_pid] = [_num, int(_pk.get("rank") or 0)]
            if _pid in _have: continue
            _pos = ((_per.get("primaryPosition") or {}).get("abbreviation") or "")
            _pit = 1 if _pos in ("P", "RHP", "LHP") else 0
            _bd = _per.get("birthDate")
            # season age (age on June 30, the convention every other row uses):
            # Eric Booth Jr., born Jul 4 2008, is 17, not 18
            _age = (2026 - int(_bd[:4]) - (1 if _bd[5:10] > "06-30" else 0)) if _bd else 21
            _grp = "SP" if _pit else ("C" if _pos == "C" else "IF" if _pos in ("1B","2B","3B","SS") else "OF")
            players.append([_per.get("fullName", "?"), _pid, _ab, _pit, _age, 0.0, 0.0, 0.0, 6, 0, 1.0, 0.0,
                            _grp, ("SP" if _pit else (_pos or "IF")), 0.0, 0, None, 0])
except Exception as _e:
    print("2026 draft fetch failed:", _e)
print("2026 draftees added:", len(DRAFT26))
_CBK = json.load(open("/work/contract_book.json"))
_EXR = json.load(open("/work/ext_class_rate.json")) if os.path.exists("/work/ext_class_rate.json") else {}
out = dict(
    draft26={str(k): v for k, v in DRAFT26.items()},
    players=players,
    curves=dict(bat=PC["curves"]["bat"], pit=PC["curves"]["pit"], pop=PC["pop_mean"],
                unrankedEV=PC["unranked_ev"], backtest=PC["backtest"]),
    market=dict(dpw={str(k): v for k, v in
                     {2026: 9.7, 2027: 10.0, 2028: 10.3, 2029: 10.6, 2030: 10.9, 2031: 11.2, 2032: 11.5}.items()},
                dpwHist={str(k): v for k, v in {2006:4.2,2007:4.5,2008:4.7,2009:4.7,2010:5.0,2011:5.2,2012:5.5,2013:6.0,
                     2014:6.5,2015:7.0,2016:7.7,2017:8.0,2018:8.2,2019:8.0,2020:8.0,2021:8.5,
                     2022:8.5,2023:9.0,2024:9.3,2025:9.5,2026:9.7}.items()},
                buckets={"rental": dict(ratio=0.8, bust=0.55), "+1": dict(ratio=0.99, bust=0.48),
                         "+2": dict(ratio=0.86, bust=0.39), "3+": dict(ratio=0.37, bust=0.71)},
                extDiscount={"predebut": 0.35, "early": 0.45, "arb": 0.60, "vet": 0.90},
                # v5.9: the channels' own expectations, so a Desk letter means what the realized grade will mean
                typ=dict(fa=_CBK["typical_fa"], faAll=_CBK["typical_fa_all"], band=_CBK.get("band_mult", {}), bands=_CBK.get("bands", [0.5, 1.5, 3.0]),
                         ext=_EXR.get("cls", _EXR))),
    slot=[[1, 9.9], [2, 7.5], [3, 6.7], [5, 5.5], [8, 4.6], [12, 3.6], [17, 3.0], [22, 2.6],
          [30, 2.1], [45, 1.5], [65, 1.1], [90, 0.85], [120, 0.6], [200, 0.35], [400, 0.18], [620, 0.10]],
    drift=1.08,   # v5.7: 2021-25 winters' contracts ran 8% above the $/win curve (median of 106 deals the ensemble priced at $25M+, full 2022-25 book; contract_model.py)
    vrank=[[1, 8.0], [3, 7.0], [5, 6.5], [10, 5.5], [15, 4.8], [25, 4.0], [40, 3.2], [50, 2.8], [75, 2.0], [100, 1.5]],   # legacy combined curve (a bare rank with no hitter/pitcher known)
    # v5.4 Top 100 rank curve, hitters and pitchers apart: six seasons of Ledger
    # WAR discounted 10% a year, fitted on the ranked 2012-2019 history
    # (prospects_peak.py VR_H / VR_P; same anchors in asset_rules, sweep_score, proj_v1)
    vrankH=[[1, 12.4], [3, 10.0], [5, 8.8], [10, 7.3], [15, 6.4], [25, 5.3], [40, 4.2], [50, 3.7], [75, 2.8], [100, 2.2]],
    vrankP=[[1, 6.7], [3, 5.5], [5, 4.9], [10, 4.2], [15, 3.7], [25, 3.2], [40, 2.6], [50, 2.4], [75, 2.0], [100, 1.6]],
    teams=teams,
    deals=compact,
    book=book,
    payroll=payroll,
    fa27=fa27,
    status={str(k): v for k, v in STATUS.items()},
    posted=POSTED,
    qoIneligible=QO_INELIG,
    pros=PROS_OUT,
    bio=(json.load(open("/work/prospect_bio.json")) if os.path.exists("/work/prospect_bio.json") else {}),   # Nov 10: how each prospect entered pro ball (prospect_bio.py)
    line26=(json.load(open("/work/line26.json")) if os.path.exists("/work/line26.json") else {}),   # Nov 10: 2026 big-league stat lines (line26_build.py)
    adv26=(json.load(open("/work/adv26.json")) if os.path.exists("/work/adv26.json") else {}),   # Nov 10: xFIP/SIERA and xwOBA from the tracker (adv26_build.py)
    peak=PEAK,
    peakBacktest=PK["backtest"],
    rankTraj=PK.get("rankTraj", {}),
    rookie=PROS["rookie"],
    t100lvl=PROS["top100Level"],
    deb26=(json.load(open("/work/debut26.json")) if os.path.exists("/work/debut26.json") else {}),
    ptx={str(k): v for k, v in PTX.items()},   # Nov 9: expected 2027 playing time (PA for hitters, IP for pitchers)
    skadj={k: v[0] for k, v in (json.load(open("/work/skill_adj.json"))["adj"].items() if os.path.exists("/work/skill_adj.json") else {}) if abs(v[0]) >= 0.02},   # Nov 3: Statcast skill adjustment to the projection base (skills_fit.py)
    arb27=ARB27,   # Nov 9: MLB Trade Rumors 2027 arbitration projections {pid: $M} (mlbtr_arb.py)
    qo27=(json.load(open("/work/qo_2027.json"))["qo"] if os.path.exists("/work/qo_2027.json") else {}),   # Nov 3: this winter's real qualifying offers {pid: club}
    cons=(json.load(open("/work/market_consensus.json")) if os.path.exists("/work/market_consensus.json") else {}),   # Nov 3: published contract projections, median per player: [years, AAV $M, sources, source keys]   # v6.1: prospects who reached the majors in 2026
    cbt={"2026": 244, "2027": None},  # 2027+ awaits the next CBA
    cachePlayers=len(LVM),            # v5.9: the page's copy reads this count
)
json.dump(out, open("/work/desk_data.json", "w"), separators=(",", ":"))
import os
print("desk_data.json:", round(os.path.getsize("/work/desk_data.json") / 1e6, 2), "MB")
